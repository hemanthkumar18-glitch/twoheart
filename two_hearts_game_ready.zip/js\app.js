// TwoHearts - Main Application Controller
// Handles screens, profiles, room links, ambient canvas, confetti, and floating reactions

class AppController {
  constructor() {
    this.currentScreen = 'screen-lobby';
    this.selectedRole = 'female';
    this.confettiParticles = [];
    this.ambientParticles = [];
  }

  init() {
    this.initAmbientBackground();
    this.initConfetti();
    this.setupEventListeners();
    this.checkUrlParams();
    this.loadSavedProfile();
    if (window.auth && typeof window.auth.init === 'function') {
      window.auth.init();
    }
  }

  // Load previously saved name and role if available
  loadSavedProfile() {
    const savedName = localStorage.getItem('twohearts_name');
    const savedRole = localStorage.getItem('twohearts_role');

    if (savedName) {
      const nameInput = document.getElementById('player-name-input');
      if (nameInput) nameInput.value = savedName;
    }

    if (savedRole) {
      this.selectRole(savedRole);
    }
  }

  // Check URL parameters (e.g. ?room=LOVE7) to streamline joining
  checkUrlParams() {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room');
    if (roomParam) {
      this.switchLobbyTab('join');
      const joinInput = document.getElementById('join-code-input');
      if (joinInput) {
        joinInput.value = roomParam.toUpperCase();
      }
    }
  }

  setupEventListeners() {
    // Network listeners
    window.network.on('room_created', ({ roomCode }) => {
      this.showWaitingHostRoom(roomCode);
    });

    window.network.on('partner_connected', ({ partner, isSingleDevice }) => {
      this.handlePartnerJoined(partner, isSingleDevice);
    });

    window.network.on('disconnected', () => {
      this.handlePartnerDisconnected();
    });

    window.network.on('error', (err) => {
      this.showToast(`⚠️ ${err}`);
    });

    window.network.on('message', ({ type, payload }) => {
      if (type === 'FLOATING_REACTION') {
        this.spawnFloatingReaction(payload.emoji, false);
      } else if (type === 'LOVE_BELL') {
        this.receiveLoveBell(payload.senderName);
      } else if (type === 'SWITCH_GAME') {
        this.openGame(payload.gameId, false);
      }
    });

    // Sound toggle button
    const soundToggle = document.getElementById('sound-toggle-btn');
    if (soundToggle) {
      soundToggle.onclick = () => {
        const isMuted = window.soundFx.toggleMute();
        soundToggle.textContent = isMuted ? '🔇' : '🔔';
        this.showToast(isMuted ? 'Muted' : 'Sound ON');
      };
      if (window.soundFx.isMuted()) {
        soundToggle.textContent = '🔇';
      }
    }
  }

  selectRole(role) {
    this.selectedRole = role;
    window.soundFx.playPop();

    const femaleCard = document.getElementById('role-card-female');
    const maleCard = document.getElementById('role-card-male');

    if (role === 'female') {
      femaleCard?.classList.add('selected-female');
      maleCard?.classList.remove('selected-male');
    } else {
      maleCard?.classList.add('selected-male');
      femaleCard?.classList.remove('selected-female');
    }
  }

  switchLobbyTab(tab) {
    window.soundFx.playPop();
    const createBtn = document.getElementById('tab-btn-create');
    const joinBtn = document.getElementById('tab-btn-join');
    const createPane = document.getElementById('tab-pane-create');
    const joinPane = document.getElementById('tab-pane-join');

    if (tab === 'create') {
      createBtn?.classList.add('active');
      joinBtn?.classList.remove('active');
      if (createPane) createPane.style.display = 'block';
      if (joinPane) joinPane.style.display = 'none';
    } else {
      joinBtn?.classList.add('active');
      createBtn?.classList.remove('active');
      if (joinPane) joinPane.style.display = 'block';
      if (createPane) createPane.style.display = 'none';
    }
  }

  getPlayerProfile() {
    const nameInput = document.getElementById('player-name-input');
    const name = nameInput?.value.trim() || (this.selectedRole === 'female' ? 'Juliet 👸' : 'Romeo 🤴');
    localStorage.setItem('twohearts_name', name);
    localStorage.setItem('twohearts_role', this.selectedRole);

    return {
      name: name,
      role: this.selectedRole,
      avatar: this.selectedRole === 'female' ? '👸' : '🤴'
    };
  }

  // Create Room action
  handleCreateRoom() {
    window.soundFx.playPop();
    const profile = this.getPlayerProfile();
    const roomCode = window.network.generateRoomCode();
    window.network.createRoom(roomCode, profile);
  }

  showWaitingHostRoom(roomCode) {
    const pane = document.getElementById('tab-pane-create');
    const shareUrl = `${window.location.origin}${window.location.pathname}?room=${roomCode}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`;

    if (pane) {
      pane.innerHTML = `
        <div class="room-code-box">
          <div class="room-code-label">YOUR PRIVATE ROOM CODE</div>
          <div class="room-code-text">${roomCode}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 12px;">Share this code with your partner!</div>
          
          <div style="margin: 12px 0;">
            <img src="${qrUrl}" alt="Scan QR Code" style="border-radius: 12px; border: 2px solid var(--border-glass); width: 140px; height: 140px; background: #fff; padding: 4px;" />
            <div style="font-size: 0.72rem; color: var(--text-muted); margin-top: 4px;">Or let them scan this QR with their camera 📸</div>
          </div>

          <div style="display: flex; gap: 8px; justify-content: center; margin-top: 10px;">
            <button class="btn btn-secondary" onclick="window.app.copyRoomLink('${shareUrl}')" style="font-size: 0.85rem; padding: 8px 14px;">
              📋 Copy Link
            </button>
            <button class="btn btn-primary" onclick="window.app.shareInvite('${roomCode}', '${shareUrl}')" style="font-size: 0.85rem; padding: 8px 14px;">
              💬 Share Invite
            </button>
          </div>
        </div>
        <div style="text-align: center; color: var(--accent-gold); font-size: 0.9rem; animation: pulse-heart 2s infinite;">
          💓 Waiting for your partner to join...
        </div>
      `;
    }

    this.updateStatusPill(false, 'WAITING...');
  }

  // Join Room action
  handleJoinRoom() {
    window.soundFx.playPop();
    const input = document.getElementById('join-code-input');
    const code = input?.value.trim().toUpperCase();

    if (!code) {
      this.showToast('Please enter the Room Code from your partner!');
      return;
    }

    const profile = this.getPlayerProfile();
    window.network.joinRoom(code, profile);
    this.updateStatusPill(false, 'CONNECTING...');
  }

  // Single device test mode
  handleSingleDeviceMode() {
    window.soundFx.playPop();
    const profile = this.getPlayerProfile();
    window.network.enableSingleDeviceMode(profile);
  }

  copyRoomLink(url) {
    window.soundFx.playPop();
    navigator.clipboard.writeText(url).then(() => {
      this.showToast('✅ Invite link copied to clipboard!');
    }).catch(() => {
      this.showToast('URL: ' + url);
    });
  }

  shareInvite(roomCode, url) {
    window.soundFx.playPop();
    if (navigator.share) {
      navigator.share({
        title: 'Play TwoHearts with me! 💖',
        text: `Hey! Join my TwoHearts couple game room: ${roomCode}`,
        url: url
      }).catch(() => {});
    } else {
      this.copyRoomLink(url);
    }
  }

  handlePartnerJoined(partner, isSingleDevice) {
    this.updateStatusPill(true, 'CONNECTED');
    window.soundFx.playSuccess();
    this.triggerConfetti();

    this.showToast(`🎉 ${partner.name} joined the room!`);

    // Switch to game selection hub
    this.showScreen('screen-hub');

    // Update duo profile banner
    this.updateDuoHeader(partner);
  }

  handlePartnerDisconnected() {
    window.soundFx.playOops();

    // 1. Stop 3D game engine if running
    if (window.pepeloGame) {
      window.pepeloGame.stop();
    }

    // 2. Hide any active modals or popups
    const modals = document.querySelectorAll('.modal-overlay, .wheel-card-modal');
    modals.forEach(m => m.style.display = 'none');

    // 3. Return directly to Home Page (Lobby)
    this.showScreen('screen-lobby');

    // 4. Update status indicator
    this.updateStatusPill(false, 'OFFLINE');

    // 5. Reset Create Room UI in case host was waiting or playing
    const pane = document.getElementById('tab-pane-create');
    if (pane) {
      pane.innerHTML = `
        <p style="font-size: 0.82rem; color: var(--text-muted); margin-bottom: 14px; text-align: center;">
          Create a private room and invite your partner via link, code, or QR!
        </p>
        <button class="btn btn-primary btn-block btn-lg" onclick="window.app.handleCreateRoom()">
          ✨ Create Private Room
        </button>
      `;
    }

    // 6. Display clear notice to player
    this.showToast('💔 Your partner closed the game. Returned to Home Page.');
  }

  updateDuoHeader(partner) {
    const myNameEl = document.getElementById('hub-my-name');
    const myAvatarEl = document.getElementById('hub-my-avatar');
    const myRing = document.getElementById('hub-my-ring');

    const partnerNameEl = document.getElementById('hub-partner-name');
    const partnerAvatarEl = document.getElementById('hub-partner-avatar');
    const partnerRing = document.getElementById('hub-partner-ring');

    const myProfile = window.network.player;

    if (myNameEl) myNameEl.textContent = myProfile.name;
    if (myAvatarEl) myAvatarEl.textContent = myProfile.avatar;
    if (myRing) myRing.className = `partner-avatar-ring ${myProfile.role}`;

    if (partnerNameEl) partnerNameEl.textContent = partner.name;
    if (partnerAvatarEl) partnerAvatarEl.textContent = partner.avatar;
    if (partnerRing) partnerRing.className = `partner-avatar-ring ${partner.role}`;
  }

  updateStatusPill(connected, text) {
    const pill = document.getElementById('status-pill');
    const textEl = document.getElementById('status-text');

    if (pill) {
      pill.className = `status-pill ${connected ? 'connected' : 'waiting'}`;
    }
    if (textEl) {
      textEl.textContent = text || (connected ? 'CONNECTED' : 'OFFLINE');
    }
  }

  showScreen(screenId) {
    const screens = document.querySelectorAll('.game-screen, #screen-lobby, #screen-hub');
    screens.forEach(s => s.classList.remove('active'));

    const target = document.getElementById(screenId);
    if (target) {
      target.classList.add('active');
      this.currentScreen = screenId;
    }

    // Show floating reaction bar only when connected
    const reactionBar = document.getElementById('reaction-bar');
    if (reactionBar) {
      reactionBar.style.display = window.network.connected ? 'flex' : 'none';
    }
  }

  openGame(gameId, broadcast = true) {
    window.soundFx.playPop();

    if (broadcast) {
      window.network.send('SWITCH_GAME', { gameId: gameId });
    }

    this.showScreen(`screen-${gameId}`);

    // Initialize specific game state
    if (gameId === 'pepelo') window.pepeloGame.init('pepelo-viewport');
    else if (gameId === 'sync') window.syncGame.init();
    else if (gameId === 'quiz') window.quizGame.init();
    else if (gameId === 'wheel') window.wheelGame.init();
    else if (gameId === 'duel') window.duelGame.init();
    else if (gameId === 'ttt') window.tttGame.init();
    else if (gameId === 'canvas') window.canvasGame.init();
  }

  backToHub() {
    window.soundFx.playPop();
    if (window.pepeloGame) window.pepeloGame.stop();
    this.showScreen('screen-hub');
    window.network.send('SWITCH_GAME', { gameId: 'hub' });
  }

  // --- FLOATING REACTIONS & LOVE BELL ---

  sendReaction(emoji) {
    window.soundFx.playPop();
    this.spawnFloatingReaction(emoji, true);
    window.network.send('FLOATING_REACTION', { emoji: emoji });
  }

  spawnFloatingReaction(emoji, isLocal = false) {
    const el = document.createElement('div');
    el.className = 'flying-reaction';
    el.textContent = emoji;

    // Random horizontal position near center
    const xPos = 20 + Math.random() * 60;
    el.style.left = `${xPos}vw`;

    document.body.appendChild(el);

    if (!isLocal) {
      window.soundFx.playHeartbeat();
    }

    setTimeout(() => {
      el.remove();
    }, 2800);
  }

  sendLoveBell() {
    window.soundFx.playBell();
    this.triggerConfetti(20);
    this.showToast('🔔 Love bell sent to your partner!');

    window.network.send('LOVE_BELL', {
      senderName: window.network.player.name
    });
  }

  receiveLoveBell(senderName) {
    window.soundFx.playBell();
    this.triggerConfetti(30);
    this.showToast(`🔔 ${senderName} is thinking of you with lots of love! 💖`);
    this.spawnFloatingReaction('💖', false);
    this.spawnFloatingReaction('🔔', false);
  }

  // --- TOAST NOTIFICATIONS ---

  showToast(message) {
    const existing = document.querySelector('.toast-notice');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast-notice';
    toast.innerHTML = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.remove();
    }, 3200);
  }

  // --- AMBIENT FLOATING HEARTS BACKGROUND ---

  initAmbientBackground() {
    const canvas = document.getElementById('ambient-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const hearts = [];
    const colors = ['rgba(255, 77, 141, 0.25)', 'rgba(77, 148, 255, 0.25)', 'rgba(157, 78, 221, 0.25)'];

    for (let i = 0; i < 24; i++) {
      hearts.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: 8 + Math.random() * 16,
        speedY: 0.3 + Math.random() * 0.6,
        speedX: (Math.random() - 0.5) * 0.4,
        color: colors[Math.floor(Math.random() * colors.length)],
        opacity: 0.2 + Math.random() * 0.4
      });
    }

    const drawHeart = (ctx, x, y, size, color) => {
      ctx.save();
      ctx.beginPath();
      ctx.translate(x, y);
      ctx.scale(size / 20, size / 20);
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(-10, -10, -20, 5, 0, 20);
      ctx.bezierCurveTo(20, 5, 10, -10, 0, 0);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.restore();
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      hearts.forEach(h => {
        h.y -= h.speedY;
        h.x += h.speedX;

        if (h.y < -30) {
          h.y = canvas.height + 20;
          h.x = Math.random() * canvas.width;
        }

        drawHeart(ctx, h.x, h.y, h.size, h.color);
      });

      requestAnimationFrame(animate);
    };

    animate();
  }

  // --- CELEBRATORY CONFETTI SYSTEM ---

  initConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const animateConfetti = () => {
      if (this.confettiParticles.length > 0) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        for (let i = this.confettiParticles.length - 1; i >= 0; i--) {
          const p = this.confettiParticles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.vy += p.gravity;
          p.rotation += p.rotationSpeed;
          p.alpha -= 0.008;

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.fillStyle = p.color;
          ctx.globalAlpha = Math.max(0, p.alpha);
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
          ctx.restore();

          if (p.alpha <= 0 || p.y > canvas.height + 20) {
            this.confettiParticles.splice(i, 1);
          }
        }
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
      requestAnimationFrame(animateConfetti);
    };

    animateConfetti();
  }

  triggerConfetti(count = 55) {
    const colors = ['#ff4d8d', '#ff758f', '#4d94ff', '#ffd166', '#06d6a0', '#9d4edd'];
    const originX = window.innerWidth / 2;
    const originY = window.innerHeight * 0.35;

    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const velocity = 4 + Math.random() * 8;
      this.confettiParticles.push({
        x: originX,
        y: originY,
        vx: Math.cos(angle) * velocity,
        vy: Math.sin(angle) * velocity - 3,
        gravity: 0.18,
        size: 7 + Math.random() * 6,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * Math.PI,
        rotationSpeed: (Math.random() - 0.5) * 0.2,
        alpha: 1.0
      });
    }
  }
}

window.app = new AppController();
window.addEventListener('DOMContentLoaded', () => {
  window.app.init();
});
