// TwoHearts - Romeo & Juliet Couple Authentication & Progress Persistence
// Allows couples to register/login by choosing Romeo (🤴) or Juliet (👸)
// Synchronizes 20-level co-op progress across separate devices and browser sessions

class AuthManager {
  constructor() {
    this.loginIdentity = 'juliet'; // 'juliet' | 'romeo'
    this.regIdentity = 'juliet';   // 'juliet' | 'romeo'

    this.session = {
      isLoggedIn: false,
      account: '',
      pin: '',
      identity: 'juliet', // 'juliet' (Queen / Pink) or 'romeo' (King / Blue)
      role: 'female',     // 'female' for Juliet, 'male' for Romeo
      nickname: 'Juliet',
      partnerIdentity: 'romeo',
      partnerNickname: 'Romeo',
      unlockedLevel: 1,
      lastPlayed: null
    };

    this.levelNames = [
      "Twin Bridges", "The Elevator", "Stepping Stones", "Double Gate",
      "Crystal Lift", "Heavy Lifting", "Color Resonance", "Laser Grid",
      "Rotating Gears", "Seesaw Bridge", "Sync Sprint", "Conveyor Maze",
      "Starry Crossway", "Sky Bouncers", "Cube Domino", "Mirror Chamber",
      "Cloud Spire", "Laser Gauntlet", "Trial of Trust", "Eternal Sanctuary"
    ];
  }

  init() {
    this.loadLocalSession();
    this.syncWithBackend();
    this.updateUI();
  }

  // Load session stored in browser localStorage
  loadLocalSession() {
    try {
      const stored = localStorage.getItem('twohearts_auth');
      if (stored) {
        const parsed = JSON.parse(stored);
        this.session = { ...this.session, ...parsed, isLoggedIn: true };
        this.loginIdentity = this.session.identity || 'juliet';
        this.regIdentity = this.session.identity || 'juliet';
      }

      // Also check fallback unlocked level
      const fallbackLvl = parseInt(localStorage.getItem('twohearts_unlocked_level') || '1', 10);
      if (fallbackLvl > this.session.unlockedLevel) {
        this.session.unlockedLevel = fallbackLvl;
      }
    } catch (e) {
      console.warn('[Auth] Failed to load local session:', e);
    }
  }

  // Persist session to localStorage
  saveLocalSession() {
    try {
      localStorage.setItem('twohearts_auth', JSON.stringify(this.session));
      localStorage.setItem('twohearts_unlocked_level', this.session.unlockedLevel.toString());
    } catch (e) {
      console.warn('[Auth] Failed to save local session:', e);
    }
  }

  // Select Romeo or Juliet on the Log In pane
  selectLoginIdentity(identity) {
    this.loginIdentity = identity;
    if (window.soundFx) window.soundFx.playPop();

    const julietCard = document.getElementById('login-id-juliet');
    const romeoCard = document.getElementById('login-id-romeo');
    const submitBtn = document.getElementById('login-submit-btn');

    if (identity === 'juliet') {
      julietCard?.classList.add('selected-juliet');
      romeoCard?.classList.remove('selected-romeo');
      if (submitBtn) {
        submitBtn.innerHTML = `🚀 Log In as Juliet & Resume Game`;
        submitBtn.className = 'btn btn-primary btn-block btn-lg';
      }
    } else {
      romeoCard?.classList.add('selected-romeo');
      julietCard?.classList.remove('selected-juliet');
      if (submitBtn) {
        submitBtn.innerHTML = `🚀 Log In as Romeo & Resume Game`;
        submitBtn.className = 'btn btn-blue btn-block btn-lg';
      }
    }
  }

  // Select Romeo or Juliet on the Register pane
  selectRegIdentity(identity) {
    this.regIdentity = identity;
    if (window.soundFx) window.soundFx.playPop();

    const julietCard = document.getElementById('reg-id-juliet');
    const romeoCard = document.getElementById('reg-id-romeo');
    const submitBtn = document.getElementById('reg-submit-btn');
    const nameInput = document.getElementById('reg-name-input');

    if (identity === 'juliet') {
      julietCard?.classList.add('selected-juliet');
      romeoCard?.classList.remove('selected-romeo');
      if (nameInput && (!nameInput.value || nameInput.value === 'Romeo')) {
        nameInput.value = 'Juliet';
      }
      if (submitBtn) {
        submitBtn.innerHTML = `✨ Create Account as Juliet`;
        submitBtn.className = 'btn btn-primary btn-block btn-lg';
      }
    } else {
      romeoCard?.classList.add('selected-romeo');
      julietCard?.classList.remove('selected-juliet');
      if (nameInput && (!nameInput.value || nameInput.value === 'Juliet')) {
        nameInput.value = 'Romeo';
      }
      if (submitBtn) {
        submitBtn.innerHTML = `✨ Create Account as Romeo`;
        submitBtn.className = 'btn btn-blue btn-block btn-lg';
      }
    }
  }

  // Swap persona between Romeo and Juliet on this device
  switchCurrentIdentity() {
    if (!this.session.isLoggedIn) return;

    const newIdentity = (this.session.identity === 'juliet') ? 'romeo' : 'juliet';
    const isJuliet = (newIdentity === 'juliet');

    this.session.identity = newIdentity;
    this.session.role = isJuliet ? 'female' : 'male';
    this.session.nickname = isJuliet ? 'Juliet' : 'Romeo';
    this.session.partnerIdentity = isJuliet ? 'romeo' : 'juliet';
    this.session.partnerNickname = isJuliet ? 'Romeo' : 'Juliet';

    this.saveLocalSession();
    this.updateUI();

    if (window.soundFx) window.soundFx.playFanfare();
    if (window.app && window.app.showToast) {
      const emoji = isJuliet ? '👸' : '🤴';
      window.app.showToast(`Switched identity to ${this.session.nickname} ${emoji}!`);
    }
  }

  // Optionally verify/sync with backend /api/auth/
  async syncWithBackend() {
    if (!this.session.isLoggedIn || !this.session.account) return;

    try {
      const res = await fetch(`/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          account: this.session.account,
          pin: this.session.pin,
          identity: this.session.identity,
          nickname: this.session.nickname,
          role: this.session.role
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.unlockedLevel) {
          if (data.unlockedLevel > this.session.unlockedLevel) {
            this.session.unlockedLevel = data.unlockedLevel;
            this.saveLocalSession();
            this.updateUI();
            if (window.app && window.app.showToast) {
              window.app.showToast(`🔄 Synced with partner! Highest Stage: ${data.unlockedLevel}`);
            }
          }
        }
      }
    } catch (e) {
      console.log('[Auth] Backend sync skipped (offline or static)');
    }
  }

  // Register a new couple account
  async register(account, pin, identity = 'juliet', nickname = '') {
    account = (account || '').trim();
    pin = (pin || '').trim();
    identity = (identity === 'romeo') ? 'romeo' : 'juliet';
    const role = (identity === 'juliet') ? 'female' : 'male';
    nickname = (nickname || '').trim() || (identity === 'juliet' ? 'Juliet' : 'Romeo');

    if (!account) {
      alert('Please enter a Couple Account name!');
      return false;
    }
    if (!pin || pin.length < 3) {
      alert('Please enter a PIN with at least 3 characters!');
      return false;
    }

    let unlockedLevel = this.session.unlockedLevel || 1;

    // Attempt backend registration
    try {
      const res = await fetch(`/api/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          account,
          pin,
          identity,
          nickname,
          role,
          unlockedLevel
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.unlockedLevel) unlockedLevel = Math.max(unlockedLevel, data.unlockedLevel);
      }
    } catch (e) {
      console.log('[Auth] Backend registration offline, using local storage.');
    }

    this.session = {
      isLoggedIn: true,
      account,
      pin,
      identity,
      role,
      nickname,
      partnerIdentity: (identity === 'juliet') ? 'romeo' : 'juliet',
      partnerNickname: (identity === 'juliet') ? 'Romeo' : 'Juliet',
      unlockedLevel,
      lastPlayed: new Date().toISOString()
    };

    this.saveLocalSession();
    this.updateUI();

    this.closeAuthModal();
    const avatar = (identity === 'juliet') ? '👸' : '🤴';
    if (window.app && window.app.showToast) {
      window.app.showToast(`✨ Welcome ${nickname} ${avatar}! Couple account created.`);
    }
    if (window.soundFx) window.soundFx.playFanfare();
    return true;
  }

  // Log in to existing couple account as Romeo or Juliet
  async login(account, pin, identity = 'juliet', nickname = '') {
    account = (account || '').trim();
    pin = (pin || '').trim();
    identity = (identity === 'romeo') ? 'romeo' : 'juliet';
    const role = (identity === 'juliet') ? 'female' : 'male';
    if (!nickname) nickname = (identity === 'juliet') ? 'Juliet' : 'Romeo';

    if (!account) {
      alert('Please enter your Couple Account name!');
      return false;
    }
    if (!pin) {
      alert('Please enter your PIN!');
      return false;
    }

    let unlockedLevel = 1;

    // Check backend
    try {
      const res = await fetch(`/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ account, pin, identity, nickname, role })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.error) {
          alert(`Login failed: ${data.error}`);
          return false;
        }
        if (data.unlockedLevel) unlockedLevel = data.unlockedLevel;
        if (data.nickname) nickname = data.nickname;
      }
    } catch (e) {
      console.log('[Auth] Backend login offline, checking local storage.');
      if (this.session.account === account && this.session.pin && this.session.pin !== pin) {
        alert('Incorrect PIN for saved account!');
        return false;
      }
      unlockedLevel = this.session.unlockedLevel || 1;
    }

    this.session = {
      isLoggedIn: true,
      account,
      pin,
      identity,
      role,
      nickname,
      partnerIdentity: (identity === 'juliet') ? 'romeo' : 'juliet',
      partnerNickname: (identity === 'juliet') ? 'Romeo' : 'Juliet',
      unlockedLevel: Math.max(unlockedLevel, this.session.unlockedLevel || 1),
      lastPlayed: new Date().toISOString()
    };

    this.saveLocalSession();
    this.updateUI();

    this.closeAuthModal();
    const avatar = (identity === 'juliet') ? '👸' : '🤴';
    if (window.app && window.app.showToast) {
      window.app.showToast(`👋 Welcome back ${nickname} ${avatar}! Stage ${this.session.unlockedLevel} ready.`);
    }
    if (window.soundFx) window.soundFx.playFanfare();
    return true;
  }

  // Save progress when a stage is cleared
  async saveProgress(level) {
    if (typeof level !== 'number' || level < 1) return;

    if (level > this.session.unlockedLevel) {
      this.session.unlockedLevel = Math.min(20, level);
      this.session.lastPlayed = new Date().toISOString();
      this.saveLocalSession();
      this.updateUI();

      if (window.app && window.app.showToast) {
        window.app.showToast(`💾 Progress Saved: Stage ${this.session.unlockedLevel} Unlocked! 🌟`);
      }

      // Sync to backend if logged in
      if (this.session.account && this.session.pin) {
        try {
          await fetch(`/api/auth/progress`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              account: this.session.account,
              pin: this.session.pin,
              level: this.session.unlockedLevel
            })
          });
        } catch (e) {
          console.log('[Auth] Progress saved locally (offline backend)');
        }
      }
    }
  }

  getUnlockedLevel() {
    return this.session.unlockedLevel || 1;
  }

  // Continue the game from highest unlocked stage
  continueGame() {
    const stageToResume = this.getUnlockedLevel();
    this.closeAuthModal();

    if (window.soundFx) window.soundFx.playPop();

    // Check if Pepelo game exists
    if (window.pepeloGame) {
      window.app.openGame('pepelo');
      window.pepeloGame.jumpToLevel(stageToResume);
      if (window.app && window.app.showToast) {
        window.app.showToast(`▶️ Resuming Stage ${stageToResume}: ${this.levelNames[stageToResume - 1] || 'Level ' + stageToResume}`);
      }
    } else {
      window.app.openGame('pepelo');
    }
  }

  // Log out
  logout() {
    if (confirm('Are you sure you want to log out on this device?')) {
      this.session = {
        isLoggedIn: false,
        account: '',
        pin: '',
        identity: 'juliet',
        role: 'female',
        nickname: 'Juliet',
        partnerIdentity: 'romeo',
        partnerNickname: 'Romeo',
        unlockedLevel: 1,
        lastPlayed: null
      };
      localStorage.removeItem('twohearts_auth');
      this.updateUI();
      this.closeAuthModal();
      if (window.app && window.app.showToast) {
        window.app.showToast('Logged out. You are now playing as Guest.');
      }
    }
  }

  // Update DOM elements representing auth state
  updateUI() {
    const isJuliet = (this.session.identity === 'juliet');
    const avatar = isJuliet ? '👸' : '🤴';
    const partnerAvatar = isJuliet ? '🤴' : '👸';
    const partnerName = isJuliet ? 'Romeo' : 'Juliet';

    // 1. Header Auth Button
    const authBtn = document.getElementById('auth-btn');
    if (authBtn) {
      if (this.session.isLoggedIn && this.session.account) {
        authBtn.innerHTML = `<span class="auth-btn-avatar">${avatar}</span> <span class="auth-btn-label">${this.session.nickname} (Lvl ${this.session.unlockedLevel})</span>`;
        authBtn.className = `account-btn logged-in ${isJuliet ? 'juliet' : 'romeo'}`;
      } else {
        authBtn.innerHTML = `<span>👤</span> <span>Login / Save</span>`;
        authBtn.className = 'account-btn';
      }
    }

    // 2. Lobby Screen Inputs & Role Selection
    if (this.session.isLoggedIn) {
      const nameInput = document.getElementById('player-name-input');
      if (nameInput) {
        nameInput.value = this.session.nickname || (isJuliet ? 'Juliet' : 'Romeo');
      }

      if (window.app && typeof window.app.selectRole === 'function') {
        window.app.selectRole(this.session.role);
      }
    }

    // 3. Continue Card on Lobby Screen
    const continueCard = document.getElementById('continue-game-banner');
    const stageTitle = document.getElementById('continue-stage-title');
    const accountInfo = document.getElementById('continue-account-info');

    if (continueCard) {
      const highest = this.getUnlockedLevel();
      if (this.session.isLoggedIn || highest > 1) {
        continueCard.style.display = 'flex';
        const name = this.levelNames[highest - 1] || `Stage ${highest}`;
        if (stageTitle) {
          stageTitle.textContent = `Resume Stage ${highest}: ${name}`;
        }
        if (accountInfo) {
          if (this.session.isLoggedIn) {
            accountInfo.textContent = `Playing as ${this.session.nickname} ${avatar} (Partner: ${partnerName} ${partnerAvatar}) • Stage ${highest}/20`;
          } else {
            accountInfo.textContent = `Highest Stage: ${highest} / 20`;
          }
        }
      } else {
        continueCard.style.display = 'none';
      }
    }

    // 4. Modal Views
    const guestView = document.getElementById('auth-view-guest');
    const profileView = document.getElementById('auth-view-profile');
    if (guestView && profileView) {
      if (this.session.isLoggedIn && this.session.account) {
        guestView.style.display = 'none';
        profileView.style.display = 'block';

        const pAvatar = document.getElementById('auth-profile-avatar');
        const pName = document.getElementById('auth-profile-name');
        const pRoleTag = document.getElementById('auth-profile-role-tag');
        const pCouple = document.getElementById('auth-profile-couple');
        const pStage = document.getElementById('auth-stat-stage');
        const pSwitchBtn = document.getElementById('auth-switch-role-btn');

        if (pAvatar) pAvatar.textContent = avatar;
        if (pName) pName.textContent = this.session.nickname;
        if (pRoleTag) {
          pRoleTag.textContent = `${avatar} ${this.session.nickname} • Partner: ${partnerName} ${partnerAvatar}`;
          pRoleTag.style.color = isJuliet ? 'var(--primary-pink)' : 'var(--primary-blue)';
        }
        if (pCouple) pCouple.textContent = `Couple Account: ${this.session.account}`;
        if (pStage) pStage.textContent = `${this.session.unlockedLevel} / 20`;
        if (pSwitchBtn) {
          pSwitchBtn.textContent = `🔄 Switch to ${partnerName} (${partnerAvatar})`;
        }
      } else {
        guestView.style.display = 'block';
        profileView.style.display = 'none';

        // Pre-select active identity in modal
        this.selectLoginIdentity(this.loginIdentity);
        this.selectRegIdentity(this.regIdentity);
      }
    }
  }

  // Modal display handlers
  openAuthModal() {
    if (window.soundFx) window.soundFx.playPop();
    const modal = document.getElementById('auth-modal');
    if (modal) {
      this.updateUI();
      modal.style.display = 'flex';
    }
  }

  closeAuthModal() {
    if (window.soundFx) window.soundFx.playPop();
    const modal = document.getElementById('auth-modal');
    if (modal) modal.style.display = 'none';
  }

  switchAuthTab(tab) {
    if (window.soundFx) window.soundFx.playPop();
    const tabLogin = document.getElementById('auth-tab-login');
    const tabRegister = document.getElementById('auth-tab-register');
    const paneLogin = document.getElementById('auth-pane-login');
    const paneRegister = document.getElementById('auth-pane-register');

    if (tab === 'login') {
      tabLogin?.classList.add('active');
      tabRegister?.classList.remove('active');
      if (paneLogin) paneLogin.style.display = 'block';
      if (paneRegister) paneRegister.style.display = 'none';
      this.selectLoginIdentity(this.loginIdentity);
    } else {
      tabRegister?.classList.add('active');
      tabLogin?.classList.remove('active');
      if (paneRegister) paneRegister.style.display = 'block';
      if (paneLogin) paneLogin.style.display = 'none';
      this.selectRegIdentity(this.regIdentity);
    }
  }

  handleLoginSubmit() {
    const account = document.getElementById('login-account-input')?.value;
    const pin = document.getElementById('login-pin-input')?.value;
    const identity = this.loginIdentity || 'juliet';
    const nickname = (identity === 'juliet') ? 'Juliet' : 'Romeo';
    this.login(account, pin, identity, nickname);
  }

  handleRegisterSubmit() {
    const account = document.getElementById('reg-account-input')?.value;
    const pin = document.getElementById('reg-pin-input')?.value;
    const identity = this.regIdentity || 'juliet';
    let nickname = document.getElementById('reg-name-input')?.value;
    if (!nickname) nickname = (identity === 'juliet') ? 'Juliet' : 'Romeo';
    this.register(account, pin, identity, nickname);
  }
}

// Global instance
window.auth = new AuthManager();
