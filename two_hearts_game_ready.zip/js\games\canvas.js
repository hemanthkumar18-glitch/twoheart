// Mini-Game 6: "Love Canvas: Live Draw & Secret Note"
// Real-time synchronized drawing whiteboard + secret love note delivery

class CanvasGame {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.isDrawing = false;
    this.currentColor = '#ff4d8d';
    this.lineWidth = 4;
    this.lastX = 0;
    this.lastY = 0;
  }

  init() {
    this.canvas = document.getElementById('draw-canvas');
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');

    // Resize canvas based on display container
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    this.setupDrawingEvents();
    this.setupListeners();
  }

  resizeCanvas() {
    if (!this.canvas) return;
    const rect = this.canvas.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      // Save current content if already drawn
      const tempImg = this.ctx ? this.canvas.toDataURL() : null;
      this.canvas.width = rect.width;
      this.canvas.height = rect.height;

      if (tempImg) {
        const img = new Image();
        img.src = tempImg;
        img.onload = () => {
          this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
        };
      }
    }
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'CANVAS_DRAW') {
        this.renderStroke(payload.x0, payload.y0, payload.x1, payload.y1, payload.color, payload.size);
      } else if (type === 'CANVAS_CLEAR') {
        this.clearCanvas(false);
      } else if (type === 'SECRET_NOTE') {
        this.receiveSecretNote(payload.note, payload.senderName);
      }
    });
  }

  setupDrawingEvents() {
    const start = (e) => {
      this.isDrawing = true;
      const coords = this.getCoords(e);
      this.lastX = coords.x;
      this.lastY = coords.y;
    };

    const move = (e) => {
      if (!this.isDrawing) return;
      const coords = this.getCoords(e);

      this.renderStroke(this.lastX, this.lastY, coords.x, coords.y, this.currentColor, this.lineWidth);

      // Send to partner normalized (0.0 to 1.0) so it scales on different screen sizes!
      const w = this.canvas.width;
      const h = this.canvas.height;
      window.network.send('CANVAS_DRAW', {
        x0: this.lastX / w,
        y0: this.lastY / h,
        x1: coords.x / w,
        y1: coords.y / h,
        color: this.currentColor,
        size: this.lineWidth
      });

      this.lastX = coords.x;
      this.lastY = coords.y;
    };

    const stop = () => {
      this.isDrawing = false;
    };

    // Mouse events
    this.canvas.addEventListener('mousedown', start);
    this.canvas.addEventListener('mousemove', move);
    window.addEventListener('mouseup', stop);

    // Touch events for mobile phones
    this.canvas.addEventListener('touchstart', (e) => {
      e.preventDefault();
      start(e.touches[0]);
    }, { passive: false });

    this.canvas.addEventListener('touchmove', (e) => {
      e.preventDefault();
      move(e.touches[0]);
    }, { passive: false });

    window.addEventListener('touchend', stop);
  }

  getCoords(e) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  }

  renderStroke(x0, y0, x1, y1, color, size) {
    if (!this.ctx) return;

    // If normalized coordinates from network, scale back to current canvas dimensions
    const w = this.canvas.width;
    const h = this.canvas.height;
    const actualX0 = (x0 <= 1.0) ? x0 * w : x0;
    const actualY0 = (y0 <= 1.0) ? y0 * h : y0;
    const actualX1 = (x1 <= 1.0) ? x1 * w : x1;
    const actualY1 = (y1 <= 1.0) ? y1 * h : y1;

    this.ctx.beginPath();
    this.ctx.moveTo(actualX0, actualY0);
    this.ctx.lineTo(actualX1, actualY1);
    this.ctx.strokeStyle = color;
    this.ctx.lineWidth = size;
    this.ctx.lineCap = 'round';
    this.ctx.lineJoin = 'round';
    this.ctx.stroke();
  }

  setColor(color, el) {
    this.currentColor = color;
    window.soundFx.playPop();
    document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('active'));
    if (el) el.classList.add('active');
  }

  clearCanvas(sendNetwork = true) {
    if (!this.ctx) return;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    window.soundFx.playPop();

    if (sendNetwork) {
      window.network.send('CANVAS_CLEAR');
    }
  }

  sendSecretNote() {
    const noteInput = document.getElementById('secret-note-input');
    if (!noteInput || !noteInput.value.trim()) return;

    const noteText = noteInput.value.trim();
    window.soundFx.playSuccess();
    window.app.triggerConfetti();

    window.network.send('SECRET_NOTE', {
      note: noteText,
      senderName: window.network.player.name
    });

    window.app.showToast('💌 Secret love note sent to your partner!');
    noteInput.value = '';
  }

  receiveSecretNote(note, senderName) {
    window.soundFx.playBell();
    window.app.triggerConfetti();

    const overlay = document.getElementById('secret-note-modal');
    const senderEl = document.getElementById('secret-note-sender');
    const textEl = document.getElementById('secret-note-text');

    if (senderEl) senderEl.textContent = `💌 Secret Note from ${senderName}:`;
    if (textEl) textEl.textContent = `"${note}"`;
    if (overlay) overlay.style.display = 'flex';
  }

  closeSecretModal() {
    window.soundFx.playPop();
    const overlay = document.getElementById('secret-note-modal');
    if (overlay) overlay.style.display = 'none';
  }
}

window.canvasGame = new CanvasGame();
