// Mini-Game 4: "Heart Rush: The Tap Duel"
// Fast-paced real-time arcade action between two devices
// Mode 1: Tug of Love (Rapid Tapping)
// Mode 2: Love Reflex (Reaction Test)

class DuelGame {
  constructor() {
    this.mode = 'tug'; // 'tug' or 'reflex'
    this.meterPosition = 50; // 0 to 100% (50 is dead center)
    this.isPlaying = false;
    this.countdownTimer = null;
    this.timeLeft = 10;
    this.myScore = 0;
    this.partnerScore = 0;

    // Reflex mode vars
    this.reflexState = 'idle'; // 'idle', 'waiting', 'ready'
    this.reflexTimeout = null;
    this.reflexStartTime = 0;
  }

  init() {
    this.setupListeners();
    this.render();
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'DUEL_TAP') {
        this.handlePartnerTap();
      } else if (type === 'DUEL_START_TUG') {
        this.startTugGame(false);
      } else if (type === 'DUEL_REFLEX_TRIGGER') {
        this.triggerReflexAction();
      } else if (type === 'DUEL_REFLEX_WIN') {
        this.handleReflexLoss(payload.winnerName, payload.ms);
      }
    });
  }

  render() {
    this.updateMeterUI();
  }

  switchMode(newMode) {
    this.mode = newMode;
    window.soundFx.playPop();
    const tugSection = document.getElementById('duel-tug-section');
    const reflexSection = document.getElementById('duel-reflex-section');

    if (newMode === 'tug') {
      if (tugSection) tugSection.style.display = 'block';
      if (reflexSection) reflexSection.style.display = 'none';
    } else {
      if (tugSection) tugSection.style.display = 'none';
      if (reflexSection) reflexSection.style.display = 'block';
    }
  }

  // --- MODE 1: TUG OF LOVE ---

  startTugCountdown() {
    if (this.isPlaying) return;
    window.soundFx.playPop();

    // Broadcast start
    window.network.send('DUEL_START_TUG');
    this.startTugGame(true);
  }

  startTugGame(initiatedByMe) {
    this.isPlaying = true;
    this.meterPosition = 50;
    this.timeLeft = 10;
    this.updateMeterUI();

    const startBtn = document.getElementById('duel-start-btn');
    const tapBtn = document.getElementById('duel-tap-btn');
    const timerDisplay = document.getElementById('duel-timer');
    const winnerDisplay = document.getElementById('duel-winner');

    if (startBtn) startBtn.style.display = 'none';
    if (tapBtn) tapBtn.style.display = 'flex';
    if (winnerDisplay) winnerDisplay.textContent = 'TAP AS FAST AS YOU CAN!';

    window.soundFx.playHeartbeat();

    clearInterval(this.countdownTimer);
    this.countdownTimer = setInterval(() => {
      this.timeLeft--;
      if (timerDisplay) timerDisplay.textContent = `${this.timeLeft}s`;

      if (this.timeLeft <= 0) {
        clearInterval(this.countdownTimer);
        this.endTugGame();
      }
    }, 1000);
  }

  handleLocalTap() {
    if (!this.isPlaying) return;

    window.soundFx.playPop();

    // Pull heart toward player's side
    // Female pulls toward 100%, Male pulls toward 0%
    const isFemale = (window.network.player.role === 'female');
    const delta = isFemale ? 3.5 : -3.5;
    this.meterPosition = Math.max(5, Math.min(95, this.meterPosition + delta));
    this.updateMeterUI();

    window.network.send('DUEL_TAP');

    // Single device simulation
    if (window.network.isSingleDevice) {
      if (Math.random() > 0.4) {
        setTimeout(() => this.handlePartnerTap(), 150);
      }
    }
  }

  handlePartnerTap() {
    if (!this.isPlaying) return;

    // Partner is opposite role
    const partnerIsFemale = (window.network.partner?.role === 'female' || window.network.player.role !== 'female');
    const delta = partnerIsFemale ? 3.5 : -3.5;
    this.meterPosition = Math.max(5, Math.min(95, this.meterPosition + delta));
    this.updateMeterUI();
  }

  updateMeterUI() {
    const heartMarker = document.getElementById('duel-heart');
    const meterFemale = document.getElementById('duel-meter-female');
    const meterMale = document.getElementById('duel-meter-male');

    if (heartMarker) {
      heartMarker.style.left = `${this.meterPosition}%`;
    }
    if (meterFemale) {
      meterFemale.style.width = `${this.meterPosition}%`;
    }
    if (meterMale) {
      meterMale.style.width = `${100 - this.meterPosition}%`;
    }
  }

  endTugGame() {
    this.isPlaying = false;
    const startBtn = document.getElementById('duel-start-btn');
    const tapBtn = document.getElementById('duel-tap-btn');
    const winnerDisplay = document.getElementById('duel-winner');

    if (startBtn) {
      startBtn.style.display = 'inline-flex';
      startBtn.textContent = 'PLAY AGAIN 🔄';
    }
    if (tapBtn) tapBtn.style.display = 'none';

    let winnerText = '';
    const myRole = window.network.player.role;
    const myName = window.network.player.name;
    const partnerName = window.network.partner?.name || 'Partner';

    if (this.meterPosition > 52) {
      // Female side won
      const femaleWon = (myRole === 'female');
      winnerText = femaleWon ? `👑 ${myName} (Queen) WON THE TUG OF LOVE! 🎉` : `👸 ${partnerName} Won! Better luck next time!`;
      if (femaleWon) {
        window.soundFx.playFanfare();
        window.app.triggerConfetti();
      } else {
        window.soundFx.playOops();
      }
    } else if (this.meterPosition < 48) {
      // Male side won
      const maleWon = (myRole === 'male');
      winnerText = maleWon ? `👑 ${myName} (King) WON THE TUG OF LOVE! 🎉` : `🤴 ${partnerName} Won! Better luck next time!`;
      if (maleWon) {
        window.soundFx.playFanfare();
        window.app.triggerConfetti();
      } else {
        window.soundFx.playOops();
      }
    } else {
      winnerText = "It's a DEAD HEAT TIE! Perfect couple balance! ⚖️💖";
      window.soundFx.playSuccess();
    }

    if (winnerDisplay) winnerDisplay.textContent = winnerText;
  }

  // --- MODE 2: REFLEX DUEL ---

  startReflexGame() {
    const reflexBox = document.getElementById('reflex-box');
    const reflexStatus = document.getElementById('reflex-status');

    this.reflexState = 'waiting';
    if (reflexBox) {
      reflexBox.style.background = 'rgba(255, 255, 255, 0.08)';
      reflexBox.style.borderColor = 'rgba(255, 255, 255, 0.2)';
    }
    if (reflexStatus) {
      reflexStatus.innerHTML = `⏳ WAIT FOR PINK... <br><small style="font-size:0.75rem;">(Do not tap yet or penalty!)</small>`;
    }

    // Host or single device triggers the random timer
    if (window.network.isHost || window.network.isSingleDevice) {
      const delay = 2000 + Math.random() * 3500;
      clearTimeout(this.reflexTimeout);
      this.reflexTimeout = setTimeout(() => {
        window.network.send('DUEL_REFLEX_TRIGGER');
        this.triggerReflexAction();
      }, delay);
    }
  }

  triggerReflexAction() {
    this.reflexState = 'ready';
    this.reflexStartTime = performance.now();
    const reflexBox = document.getElementById('reflex-box');
    const reflexStatus = document.getElementById('reflex-status');

    if (reflexBox) {
      reflexBox.style.background = 'linear-gradient(135deg, #ff4d8d, #ff2b76)';
      reflexBox.style.borderColor = '#ffffff';
      reflexBox.style.boxShadow = '0 0 40px rgba(255, 77, 141, 0.8)';
    }
    if (reflexStatus) {
      reflexStatus.innerHTML = `💥 TAP NOW! 💥`;
    }
    window.soundFx.playHeartbeat();
  }

  handleReflexTap() {
    const reflexStatus = document.getElementById('reflex-status');

    if (this.reflexState === 'waiting') {
      // False start!
      window.soundFx.playOops();
      if (reflexStatus) {
        reflexStatus.innerHTML = `⚠️ False start! You tapped too early!`;
      }
      return;
    }

    if (this.reflexState === 'ready') {
      this.reflexState = 'idle';
      const reactionTime = Math.round(performance.now() - this.reflexStartTime);
      window.soundFx.playFanfare();
      window.app.triggerConfetti();

      const myName = window.network.player.name;
      if (reflexStatus) {
        reflexStatus.innerHTML = `🏆 YOU WON! <br><small>${reactionTime}ms ultra fast!</small>`;
      }

      window.network.send('DUEL_REFLEX_WIN', {
        winnerName: myName,
        ms: reactionTime
      });
    }
  }

  handleReflexLoss(winnerName, ms) {
    this.reflexState = 'idle';
    window.soundFx.playOops();
    const reflexStatus = document.getElementById('reflex-status');
    if (reflexStatus) {
      reflexStatus.innerHTML = `⚡ ${winnerName} tapped first! (${ms}ms)`;
    }
  }
}

window.duelGame = new DuelGame();
