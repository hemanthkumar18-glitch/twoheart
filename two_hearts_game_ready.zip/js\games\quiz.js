// Mini-Game 2: "How Well Do You Know Me?"
// One player answers honestly about themselves; the partner guesses!
// Scores track who knows their partner best.

class QuizGame {
  constructor() {
    this.questions = [
      {
        q: 'What is my ultimate go-to comfort food when I am feeling down or tired?',
        options: ['Warm cheesy pizza or pasta', 'Sweet chocolate, cake, or ice cream', 'A hot savory bowl of soup or noodles', 'Crispy spicy fried chicken / snacks']
      },
      {
        q: 'What is my biggest everyday pet peeve?',
        options: ['People being chronically late', 'Slow internet or buffering videos', 'Loud chewing or noisy eaters', 'A messy or cluttered room']
      },
      {
        q: 'How do I prefer spending a lazy Sunday morning?',
        options: ['Sleeping in until late noon with blankets', 'Cozy coffee in bed while scrolling / reading', 'Going out early for brunch or a walk', 'Watching movies or playing games in pajamas']
      },
      {
        q: 'If I could wake up tomorrow with one superpower, what would I pick?',
        options: ['Teleportation (instant travel anywhere!)', 'Mind reading (knowing what people think!)', 'Time travel (pause or revisit memories)', 'Invisibility']
      },
      {
        q: 'What is my absolute favorite way to receive affection from you?',
        options: ['Long, warm, silent hugs', 'Forehead or cheek kisses throughout the day', 'Holding hands whenever we walk together', 'Playful teasing and tickles']
      },
      {
        q: 'What kind of music puts me in the best mood instantly?',
        options: ['Upbeat Pop / Dance hits', 'Chill Lo-Fi / Acoustic / Indie', 'Romantic R&B / Soul ballads', 'High energy Rock / Hip-hop']
      },
      {
        q: 'If I won a 1 million dollar lottery today, what is the FIRST thing I would do?',
        options: ['Book a luxury vacation for both of us', 'Buy or design our dream home', 'Invest it wisely to retire early', 'Go on a wild luxury shopping spree']
      }
    ];

    this.currentIndex = 0;
    this.starRole = 'female'; // 'female' or 'male' is answering about themselves
    this.starAnswer = null;
    this.guesserAnswer = null;
    this.femaleScore = 0;
    this.maleScore = 0;
  }

  init() {
    this.setupListeners();
    this.render();
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'QUIZ_STAR_ANSWER') {
        this.starAnswer = payload.answer;
        this.checkResolution();
      } else if (type === 'QUIZ_GUESS_ANSWER') {
        this.guesserAnswer = payload.answer;
        this.checkResolution();
      } else if (type === 'QUIZ_NEXT') {
        this.currentIndex = payload.index;
        this.starRole = payload.starRole;
        this.starAnswer = null;
        this.guesserAnswer = null;
        this.render();
      }
    });
  }

  isCurrentStar() {
    return window.network.player.role === this.starRole;
  }

  render() {
    const qData = this.questions[this.currentIndex % this.questions.length];
    const roleIndicator = document.getElementById('quiz-role-indicator');
    const qText = document.getElementById('quiz-question');
    const optionsGrid = document.getElementById('quiz-options');
    const resultBox = document.getElementById('quiz-result');
    const nextBtn = document.getElementById('quiz-next-btn');

    if (resultBox) resultBox.classList.remove('show');
    if (nextBtn) nextBtn.style.display = 'none';

    const starName = (this.starRole === window.network.player.role)
      ? `${window.network.player.name} (YOU)`
      : `${window.network.partner?.name || 'Partner'}`;

    const isStar = this.isCurrentStar();

    if (roleIndicator) {
      if (isStar) {
        roleIndicator.innerHTML = `<span style="color: var(--accent-gold);">⭐ YOU ARE THE STAR!</span> Answer honestly about yourself:`;
      } else {
        roleIndicator.innerHTML = `<span style="color: var(--primary-pink);">🕵️ YOU ARE GUESSING!</span> Guess what <b>${starName}</b> will pick:`;
      }
    }

    if (qText) qText.textContent = qData.q;

    if (optionsGrid) {
      optionsGrid.innerHTML = '';
      qData.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'sync-option-btn';
        btn.innerHTML = `<span style="color: var(--accent-gold); font-weight:700;">${idx + 1}.</span> <span>${opt}</span>`;
        btn.onclick = () => this.handlePick(idx, btn);
        optionsGrid.appendChild(btn);
      });
    }

    this.updateScoreboard();
  }

  handlePick(idx, btnEl) {
    const isStar = this.isCurrentStar();

    if (isStar && this.starAnswer !== null) return;
    if (!isStar && this.guesserAnswer !== null) return;

    window.soundFx.playPop();

    const allBtns = document.querySelectorAll('#quiz-options .sync-option-btn');
    allBtns.forEach(b => b.classList.remove('selected'));
    btnEl.classList.add('selected');

    if (isStar) {
      this.starAnswer = idx;
      window.network.send('QUIZ_STAR_ANSWER', { answer: idx });
    } else {
      this.guesserAnswer = idx;
      window.network.send('QUIZ_GUESS_ANSWER', { answer: idx });
    }

    if (window.network.isSingleDevice) {
      if (isStar && this.guesserAnswer === null) {
        this.guesserAnswer = Math.random() > 0.4 ? this.starAnswer : Math.floor(Math.random() * 4);
      } else if (!isStar && this.starAnswer === null) {
        this.starAnswer = this.guesserAnswer;
      }
    }

    this.checkResolution();
  }

  checkResolution() {
    if (this.starAnswer !== null && this.guesserAnswer !== null) {
      this.showOutcome();
    }
  }

  showOutcome() {
    const qData = this.questions[this.currentIndex % this.questions.length];
    const isCorrect = (this.starAnswer === this.guesserAnswer);
    const resultBox = document.getElementById('quiz-result');
    const nextBtn = document.getElementById('quiz-next-btn');

    const guesserRole = (this.starRole === 'female') ? 'male' : 'female';
    if (isCorrect) {
      if (guesserRole === 'female') this.femaleScore += 10;
      else this.maleScore += 10;
      window.soundFx.playSuccess();
      window.app.triggerConfetti();
    } else {
      window.soundFx.playOops();
    }

    const starAnswerText = qData.options[this.starAnswer];
    const guesserAnswerText = qData.options[this.guesserAnswer];

    const starName = (this.starRole === window.network.player.role)
      ? window.network.player.name
      : (window.network.partner?.name || 'Partner');

    const guesserName = (this.starRole === window.network.player.role)
      ? (window.network.partner?.name || 'Partner')
      : window.network.player.name;

    let html = '';
    if (isCorrect) {
      html = `
        <div style="font-size: 2rem;">🎯 BINGO! PERFECT GUESS!</div>
        <div style="color: #06d6a0; font-weight: 700; margin: 6px 0;">+10 Points to ${guesserName}!</div>
        <div style="background: rgba(6, 214, 160, 0.2); padding: 12px; border-radius: 12px; font-weight: 600;">
          "${starAnswerText}"
        </div>
      `;
    } else {
      html = `
        <div style="font-size: 1.8rem;">🙈 Almost! But not quite!</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; text-align: left;">
          <div style="background: rgba(255, 77, 141, 0.2); padding: 10px; border-radius: 10px;">
            <div style="font-size: 0.75rem; color: var(--accent-gold); font-weight: 700;">${starName}'s Real Answer:</div>
            <div style="font-size: 0.85rem; font-weight: 600;">"${starAnswerText}"</div>
          </div>
          <div style="background: rgba(255, 255, 255, 0.1); padding: 10px; border-radius: 10px;">
            <div style="font-size: 0.75rem; color: var(--text-muted); font-weight: 700;">${guesserName}'s Guess:</div>
            <div style="font-size: 0.85rem; font-weight: 600;">"${guesserAnswerText}"</div>
          </div>
        </div>
      `;
    }

    if (resultBox) {
      resultBox.innerHTML = html;
      resultBox.classList.add('show');
    }

    this.updateScoreboard();

    if (nextBtn) {
      nextBtn.style.display = 'inline-flex';
    }
  }

  updateScoreboard() {
    const scoreEl = document.getElementById('quiz-scores');
    if (scoreEl) {
      const myRole = window.network.player.role;
      const myScore = (myRole === 'female') ? this.femaleScore : this.maleScore;
      const partnerScore = (myRole === 'female') ? this.maleScore : this.femaleScore;
      const partnerName = window.network.partner?.name || 'Partner';
      scoreEl.innerHTML = `
        <span style="color: var(--primary-pink);">You: ${myScore} pts</span> | 
        <span style="color: var(--primary-blue);">${partnerName}: ${partnerScore} pts</span>
      `;
    }
  }

  nextRound() {
    window.soundFx.playPop();
    const nextIdx = (this.currentIndex + 1) % this.questions.length;
    const nextStarRole = (this.starRole === 'female') ? 'male' : 'female';
    this.currentIndex = nextIdx;
    this.starRole = nextStarRole;
    this.starAnswer = null;
    this.guesserAnswer = null;
    this.render();

    window.network.send('QUIZ_NEXT', {
      index: nextIdx,
      starRole: nextStarRole
    });
  }
}

window.quizGame = new QuizGame();
