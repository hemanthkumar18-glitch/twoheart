// Mini-Game 1: "Telepathy: Think as One" (Couple Mind-Match)
// Both players answer simultaneously - see if your thoughts synchronize!

class SyncGame {
  constructor() {
    this.questions = [
      {
        cat: '💖 Romantic Chemistry',
        q: 'Our ideal cozy Friday night together?',
        options: ['Snuggling up with movies & takeout', 'Romantic candlelit dinner & wine', 'Late-night long drive with music', 'Cooking a delicious meal together']
      },
      {
        cat: '😂 Daily Life & Habits',
        q: 'Who takes longer to get ready to go out?',
        options: ['Definitely Her 👸', 'Definitely Him 🤴', 'Both take equal time', 'Depends on where we are going']
      },
      {
        cat: '✈️ Travel & Adventure',
        q: 'If we could teleport to a dream getaway right now, where?',
        options: ['Sun-kissed tropical beach & private villa', 'Snowy mountain cabin by a warm fireplace', 'Enchanting historic streets in Europe', 'Cozy remote forest treehouse']
      },
      {
        cat: '🍕 Food & Cravings',
        q: 'It is midnight and we are starving. What are we eating?',
        options: ['Cheesy loaded pizza', 'Burgers & crispy fries', 'Sweet ice cream & brownies', 'Spicy midnight noodles']
      },
      {
        cat: '💖 Romantic Chemistry',
        q: 'What is the most attractive quality about your partner?',
        options: ['Their warm, radiant smile & eyes', 'Their sense of humor & laughs', 'Their deep caring heart & loyalty', 'Their intelligence & ambition']
      },
      {
        cat: '🤔 Would You Rather',
        q: 'Would you rather have a 1-hour relaxing massage or your partner cook your dream feast?',
        options: ['1-Hour dreamy massage from partner', 'Partner cooks delicious 3-course feast', 'Do both together!']
      },
      {
        cat: '😂 Daily Life & Habits',
        q: 'Who is more likely to fall asleep first during a movie?',
        options: ['Him 🤴 - snoring in 15 mins!', 'Her 👸 - out like a light!', 'Both stay awake together', 'Depends on how boring the movie is']
      },
      {
        cat: '💖 Romantic Chemistry',
        q: 'Who was the first one to realize they had feelings?',
        options: ['He knew first! 🤴', 'She knew first! 👸', 'At the exact same moment ✨', 'Still a mystery to this day!']
      },
      {
        cat: '🧠 Deep Connection',
        q: 'What makes you feel most loved and appreciated?',
        options: ['Warm hugs & gentle physical touch', 'Sweet words of praise & love notes', 'Thoughtful surprise gifts & acts', 'Undivided quality time together']
      },
      {
        cat: '😂 Daily Life & Habits',
        q: 'Who is the bigger drama queen when having a mild cold/fever?',
        options: ['Him 🤴 (needs hospital care!)', 'Her 👸 (needs 24/7 pampered princess treatment!)', 'Neither, we are tough warriors!', 'Both act like babies!']
      },
      {
        cat: '🤔 Would You Rather',
        q: 'Would you rather receive 100 cute text messages a day or 1 long heartfelt call at night?',
        options: ['100 cute texts throughout the day 💬', '1 deep, intimate late-night call 🌙']
      },
      {
        cat: '🧠 Deep Connection',
        q: 'When we have a small disagreement, what resolves it fastest?',
        options: ['A warm hug and saying sorry', 'A little cooling-off space, then talking', 'Making each other laugh with a silly face', 'Ordering favorite comfort food']
      }
    ];

    this.currentIndex = 0;
    this.myChoice = null;
    this.partnerChoice = null;
    this.score = 0;
    this.totalRounds = 0;
  }

  init() {
    this.renderQuestion();
    this.setupListeners();
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'SYNC_SUBMIT') {
        this.partnerChoice = payload.choice;
        this.checkBothAnswered();
      } else if (type === 'SYNC_NEXT') {
        this.loadQuestion(payload.index);
      }
    });
  }

  loadQuestion(index) {
    this.currentIndex = index % this.questions.length;
    this.myChoice = null;
    this.partnerChoice = null;
    this.renderQuestion();
  }

  renderQuestion() {
    const qData = this.questions[this.currentIndex];
    const catEl = document.getElementById('sync-category');
    const qEl = document.getElementById('sync-question');
    const optionsGrid = document.getElementById('sync-options');
    const resultBox = document.getElementById('sync-result');
    const waitingNotice = document.getElementById('sync-waiting');

    if (catEl) catEl.textContent = qData.cat;
    if (qEl) qEl.textContent = qData.q;
    if (resultBox) resultBox.classList.remove('show');
    if (waitingNotice) waitingNotice.style.display = 'none';

    if (optionsGrid) {
      optionsGrid.innerHTML = '';
      qData.options.forEach((opt, idx) => {
        const btn = document.createElement('button');
        btn.className = 'sync-option-btn';
        btn.innerHTML = `<span style="font-weight:700; color: var(--accent-gold);">${idx + 1}.</span> <span>${opt}</span>`;
        btn.onclick = () => this.handlePick(idx, btn);
        optionsGrid.appendChild(btn);
      });
    }

    const nextBtn = document.getElementById('sync-next-btn');
    if (nextBtn) nextBtn.style.display = 'none';
  }

  handlePick(idx, btnEl) {
    if (this.myChoice !== null) return; // already picked

    this.myChoice = idx;
    window.soundFx.playPop();

    // Mark button as selected
    const allBtns = document.querySelectorAll('.sync-option-btn');
    allBtns.forEach(b => b.classList.remove('selected'));
    btnEl.classList.add('selected');

    // Send to partner
    window.network.send('SYNC_SUBMIT', { choice: idx });

    const waitingNotice = document.getElementById('sync-waiting');
    if (this.partnerChoice === null && !window.network.isSingleDevice) {
      if (waitingNotice) {
        waitingNotice.textContent = `Locked in! Waiting for ${window.network.partner?.name || 'partner'}... 🔒`;
        waitingNotice.style.display = 'block';
      }
    } else {
      this.checkBothAnswered();
    }
  }

  checkBothAnswered() {
    if (window.network.isSingleDevice) {
      // In single device mode simulate partner picking random or same
      if (this.partnerChoice === null) {
        this.partnerChoice = Math.random() > 0.4 ? this.myChoice : Math.floor(Math.random() * this.questions[this.currentIndex].options.length);
      }
    }

    if (this.myChoice !== null && this.partnerChoice !== null) {
      this.revealResults();
    }
  }

  revealResults() {
    const qData = this.questions[this.currentIndex];
    const isMatch = (this.myChoice === this.partnerChoice);
    this.totalRounds++;
    if (isMatch) this.score++;

    const resultBox = document.getElementById('sync-result');
    const waitingNotice = document.getElementById('sync-waiting');
    if (waitingNotice) waitingNotice.style.display = 'none';

    const myName = window.network.player.name;
    const partnerName = window.network.partner?.name || 'Partner';
    const myText = qData.options[this.myChoice];
    const partnerText = qData.options[this.partnerChoice];

    let resultHtml = '';
    if (isMatch) {
      window.soundFx.playSuccess();
      window.app.triggerConfetti();
      resultHtml = `
        <div style="font-size: 2.2rem; margin-bottom: 6px;">✨ 100% SOULMATE SYNC! ✨</div>
        <div style="font-weight: 700; color: #06d6a0; margin-bottom: 8px;">You both picked:</div>
        <div style="background: rgba(6, 214, 160, 0.2); border: 1.5px solid #06d6a0; padding: 12px; border-radius: 12px; font-weight: 600;">
          "${myText}"
        </div>
        <div style="margin-top: 10px; font-size: 0.85rem; color: var(--accent-gold);">Telepathy score: ${this.score} / ${this.totalRounds}</div>
      `;
    } else {
      window.soundFx.playOops();
      resultHtml = `
        <div style="font-size: 2rem; margin-bottom: 6px;">⚡ Opposites Attract! 😉</div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px; text-align: left;">
          <div style="background: rgba(255, 77, 141, 0.15); border: 1px solid var(--primary-pink); padding: 10px; border-radius: 10px;">
            <div style="font-size: 0.75rem; color: var(--primary-pink); font-weight: 700;">${myName}:</div>
            <div style="font-size: 0.85rem; font-weight: 600;">"${myText}"</div>
          </div>
          <div style="background: rgba(77, 148, 255, 0.15); border: 1px solid var(--primary-blue); padding: 10px; border-radius: 10px;">
            <div style="font-size: 0.75rem; color: var(--primary-blue); font-weight: 700;">${partnerName}:</div>
            <div style="font-size: 0.85rem; font-weight: 600;">"${partnerText}"</div>
          </div>
        </div>
        <div style="margin-top: 10px; font-size: 0.85rem; color: var(--text-muted);">Telepathy score: ${this.score} / ${this.totalRounds}</div>
      `;
    }

    if (resultBox) {
      resultBox.innerHTML = resultHtml;
      resultBox.classList.add('show');
    }

    const nextBtn = document.getElementById('sync-next-btn');
    if (nextBtn) {
      nextBtn.style.display = 'inline-flex';
    }
  }

  nextRound() {
    window.soundFx.playPop();
    const nextIdx = (this.currentIndex + 1) % this.questions.length;
    this.loadQuestion(nextIdx);
    window.network.send('SYNC_NEXT', { index: nextIdx });
  }
}

window.syncGame = new SyncGame();
