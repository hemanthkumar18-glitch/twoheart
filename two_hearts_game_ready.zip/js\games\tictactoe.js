// Mini-Game 5: "Crowns & Hearts: Tic-Tac-Toe DUO"
// King 🤴 (Blue) vs Queen 👸 (Pink) with real-time turn sync and win streaks

class TicTacToeGame {
  constructor() {
    this.board = Array(9).fill(null);
    this.currentTurn = 'female'; // 'female' starts first
    this.winner = null;
    this.winLine = null;
    this.queenWins = 0;
    this.kingWins = 0;
    this.draws = 0;
  }

  init() {
    this.setupListeners();
    this.render();
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'TTT_MOVE') {
        this.applyMove(payload.index, payload.role, false);
      } else if (type === 'TTT_RESET') {
        this.resetBoard(false);
      }
    });
  }

  render() {
    const boardEl = document.getElementById('ttt-board');
    const statusEl = document.getElementById('ttt-status');
    const scoreEl = document.getElementById('ttt-scores');

    if (boardEl) {
      boardEl.innerHTML = '';
      this.board.forEach((val, idx) => {
        const cell = document.createElement('div');
        cell.className = 'ttt-cell';
        if (val) {
          cell.classList.add('taken');
          cell.innerHTML = val === 'female' ? '👸' : '🤴';
        }
        if (this.winLine && this.winLine.includes(idx)) {
          cell.classList.add('win-cell');
        }
        cell.onclick = () => this.handleCellClick(idx);
        boardEl.appendChild(cell);
      });
    }

    if (statusEl) {
      if (this.winner) {
        if (this.winner === 'draw') {
          statusEl.innerHTML = `<span style="color: var(--accent-gold);">🤝 It's a Draw! Both are equally clever!</span>`;
        } else {
          const winnerName = (this.winner === window.network.player.role)
            ? 'YOU WON! 🏆'
            : `${window.network.partner?.name || 'Partner'} Won! 👑`;
          const winColor = (this.winner === 'female') ? 'var(--primary-pink)' : 'var(--primary-blue)';
          statusEl.innerHTML = `<span style="color: ${winColor}; font-weight:700;">${winnerName}</span>`;
        }
      } else {
        const isMyTurn = (this.currentTurn === window.network.player.role);
        if (isMyTurn) {
          statusEl.innerHTML = `<span style="color: var(--accent-gold); font-weight:700;">✨ YOUR TURN! Tap an empty square!</span>`;
        } else {
          const partnerName = window.network.partner?.name || 'Partner';
          statusEl.innerHTML = `<span style="color: var(--text-muted);">Waiting for ${partnerName}'s move...</span>`;
        }
      }
    }

    if (scoreEl) {
      scoreEl.innerHTML = `
        <span style="color: var(--primary-pink);">👸 Queen: ${this.queenWins}</span> | 
        <span style="color: var(--primary-blue);">🤴 King: ${this.kingWins}</span> | 
        <span style="color: var(--text-muted);">Ties: ${this.draws}</span>
      `;
    }
  }

  handleCellClick(idx) {
    if (this.winner) return;
    if (this.board[idx] !== null) return;

    // Check if it's my turn
    if (this.currentTurn !== window.network.player.role) {
      window.soundFx.playOops();
      return;
    }

    this.applyMove(idx, window.network.player.role, true);

    // Single device simulation
    if (window.network.isSingleDevice && !this.winner) {
      setTimeout(() => {
        const emptyCells = this.board.map((v, i) => v === null ? i : null).filter(v => v !== null);
        if (emptyCells.length > 0) {
          const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
          const partnerRole = (window.network.player.role === 'female') ? 'male' : 'female';
          this.applyMove(randomCell, partnerRole, false);
        }
      }, 400);
    }
  }

  applyMove(idx, role, sendNetwork = false) {
    if (this.board[idx] !== null || this.winner) return;

    this.board[idx] = role;
    window.soundFx.playPop();

    if (sendNetwork) {
      window.network.send('TTT_MOVE', { index: idx, role: role });
    }

    this.checkGameStatus();
    if (!this.winner) {
      this.currentTurn = (this.currentTurn === 'female') ? 'male' : 'female';
    }
    this.render();
  }

  checkGameStatus() {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
      [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    for (const [a, b, c] of lines) {
      if (this.board[a] && this.board[a] === this.board[b] && this.board[a] === this.board[c]) {
        this.winner = this.board[a];
        this.winLine = [a, b, c];

        if (this.winner === 'female') this.queenWins++;
        else this.kingWins++;

        if (this.winner === window.network.player.role) {
          window.soundFx.playFanfare();
          window.app.triggerConfetti();
        } else {
          window.soundFx.playSuccess();
        }
        return;
      }
    }

    // Check draw
    if (!this.board.includes(null)) {
      this.winner = 'draw';
      this.draws++;
      window.soundFx.playOops();
    }
  }

  resetBoard(sendNetwork = true) {
    this.board = Array(9).fill(null);
    this.winner = null;
    this.winLine = null;
    this.currentTurn = 'female';
    window.soundFx.playPop();

    if (sendNetwork) {
      window.network.send('TTT_RESET');
    }
    this.render();
  }
}

window.tttGame = new TicTacToeGame();
