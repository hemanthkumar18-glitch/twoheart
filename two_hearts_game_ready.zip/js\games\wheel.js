// Mini-Game 3: "Truth, Dare & Pillow Talk Wheel"
// Canvas-rendered interactive spinning wheel with synchronized physics

class WheelGame {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.isSpinning = false;
    this.currentAngle = 0;
    this.segments = [
      { name: '🌸 Sweet Truth', color: '#ff4d8d', type: 'sweet' },
      { name: '🔥 Spicy Dare', color: '#ff2b76', type: 'spicy' },
      { name: '🧠 Pillow Talk', color: '#9d4edd', type: 'pillow' },
      { name: '🎭 Wild Dare', color: '#ffd166', type: 'wild' },
      { name: '💖 Confession', color: '#ff758f', type: 'confess' },
      { name: '💋 Flirty Action', color: '#e63946', type: 'flirt' }
    ];

    this.decks = {
      sweet: [
        'What was your exact first impression of me the day we met?',
        'What is one tiny habit of mine that secretly makes your heart melt?',
        'Give your partner a sincere 30-second compliment looking straight into their eyes (or via camera/voice message)!',
        'What is a memory with your partner that you will cherish forever?',
        'What is your favorite outfit or look on your partner?'
      ],
      spicy: [
        'Whisper (or send a voice note) of the most flirty thing you have thought about your partner this week!',
        'Give your partner a 1-minute slow shoulder or neck massage (or send a spicy romantic promise for your next meet)!',
        'Look at your partner without laughing or blinking for 45 seconds while maintaining eye contact!',
        'What is your secret fantasy or romantic bucket-list experience for the two of you?',
        'Describe your partner using only 3 seductive or romantic words!'
      ],
      pillow: [
        'Where do you see our relationship in 5 years? Describe our dream life.',
        'What is something you have been stressed about lately that you have not fully shared?',
        'What is one way I can be an even better, more supportive partner to you?',
        'What is something you learned about love from being with me?',
        'What is a dream or passion of yours you want us to accomplish together?'
      ],
      wild: [
        'Send an unedited, funny goofy selfie right now or do a silly 10-second dance on camera!',
        'Speak in a fake dramatic romantic accent for the next 3 rounds of the game!',
        'Sing the chorus of our favorite song (or a silly love song) with maximum passion!',
        'Let your partner pick any nickname for you that you must answer to for the rest of today!',
        'Tell the cheesiest pickup line you know with complete seriousness!'
      ],
      confess: [
        'What was the exact moment you realized you had fallen for your partner?',
        'Have you ever had a silly dream about your partner? Tell the story!',
        'What is one song that always makes you think about your partner whenever it plays?',
        'What was something you were nervous about before our very first conversation or date?'
      ],
      flirt: [
        'Send a playful flirty kiss emoji attack or blow a real kiss right now!',
        'What is the most kissable feature on your partner?',
        'Rate your partner attractiveness from 1 to 10 (careful with your answer! 😉)',
        'Send your partner a 5-second flirty audio recording right now!'
      ]
    };
  }

  init() {
    this.canvas = document.getElementById('wheel-canvas');
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.drawWheel();
    this.setupListeners();
  }

  setupListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (type === 'WHEEL_SPIN') {
        this.spinTo(payload.targetAngle, payload.selectedSegment, payload.prompt);
      }
    });
  }

  drawWheel() {
    if (!this.ctx) return;
    const width = this.canvas.width;
    const height = this.canvas.height;
    const radius = width / 2 - 10;
    const center = width / 2;
    const numSegments = this.segments.length;
    const arc = (2 * Math.PI) / numSegments;

    this.ctx.clearRect(0, 0, width, height);

    this.segments.forEach((seg, i) => {
      const angle = this.currentAngle + i * arc;

      // Slice
      this.ctx.beginPath();
      this.ctx.fillStyle = seg.color;
      this.ctx.moveTo(center, center);
      this.ctx.arc(center, center, radius, angle, angle + arc);
      this.ctx.lineTo(center, center);
      this.ctx.fill();

      // Border line
      this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();

      // Text label
      this.ctx.save();
      this.ctx.translate(center, center);
      this.ctx.rotate(angle + arc / 2);
      this.ctx.textAlign = 'right';
      this.ctx.fillStyle = '#ffffff';
      this.ctx.font = 'bold 13px Poppins, sans-serif';
      this.ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
      this.ctx.shadowBlur = 4;
      this.ctx.fillText(seg.name, radius - 15, 5);
      this.ctx.restore();
    });

    // Center jewel
    this.ctx.beginPath();
    this.ctx.arc(center, center, 24, 0, 2 * Math.PI);
    this.ctx.fillStyle = '#1a1533';
    this.ctx.fill();
    this.ctx.strokeStyle = '#ffd166';
    this.ctx.lineWidth = 3;
    this.ctx.stroke();

    // Center heart icon
    this.ctx.font = '16px sans-serif';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.fillText('💖', center, center);
  }

  startSpin() {
    if (this.isSpinning) return;

    window.soundFx.playPop();

    // Pick a random target segment
    const segIndex = Math.floor(Math.random() * this.segments.length);
    const selectedSeg = this.segments[segIndex];
    const deck = this.decks[selectedSeg.type] || this.decks.sweet;
    const prompt = deck[Math.floor(Math.random() * deck.length)];

    // Target rotation: multiple full 360 spins + segment offset
    const numSegments = this.segments.length;
    const arc = (2 * Math.PI) / numSegments;
    // Pointer is at TOP (3 * Math.PI / 2)
    const targetSectorAngle = (3 * Math.PI / 2) - (segIndex * arc + arc / 2);
    const extraRotations = (5 + Math.floor(Math.random() * 3)) * (2 * Math.PI);
    const finalAngle = extraRotations + targetSectorAngle;

    // Send to partner so their wheel spins synchronously!
    window.network.send('WHEEL_SPIN', {
      targetAngle: finalAngle,
      selectedSegment: selectedSeg,
      prompt: prompt
    });

    this.spinTo(finalAngle, selectedSeg, prompt);
  }

  spinTo(targetAngle, segment, prompt) {
    if (this.isSpinning) return;
    this.isSpinning = true;

    const modal = document.getElementById('wheel-modal');
    if (modal) modal.classList.remove('show');

    const startAngle = this.currentAngle;
    const delta = targetAngle - (startAngle % (2 * Math.PI));
    const duration = 4000;
    const startTime = performance.now();
    let lastTickAngle = startAngle;

    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic
      const ease = 1 - Math.pow(1 - progress, 3);
      this.currentAngle = startAngle + delta * ease;
      this.drawWheel();

      // Sound effect tick when crossing segment lines
      if (Math.abs(this.currentAngle - lastTickAngle) > 0.4) {
        window.soundFx.playTick();
        lastTickAngle = this.currentAngle;
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        this.isSpinning = false;
        this.showPromptModal(segment, prompt);
      }
    };

    requestAnimationFrame(animate);
  }

  showPromptModal(segment, prompt) {
    window.soundFx.playSuccess();
    window.app.triggerConfetti();

    const modal = document.getElementById('wheel-modal');
    const titleEl = document.getElementById('wheel-card-title');
    const promptEl = document.getElementById('wheel-card-prompt');

    if (titleEl) {
      titleEl.innerHTML = `<span style="color: ${segment.color};">${segment.name}</span>`;
    }
    if (promptEl) {
      promptEl.textContent = prompt;
    }
    if (modal) {
      modal.classList.add('show');
    }
  }

  completeChallenge() {
    window.soundFx.playSuccess();
    const modal = document.getElementById('wheel-modal');
    if (modal) modal.classList.remove('show');
    window.app.showToast('Challenge completed! You two are adorable! 💖');
  }
}

window.wheelGame = new WheelGame();
