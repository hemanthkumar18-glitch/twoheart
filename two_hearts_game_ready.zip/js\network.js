// Dual-Engine Real-Time Network Manager for TwoHearts
// Engine 1: C++ Native Game Server (REST & Socket Relay API)
// Engine 2: WebRTC PeerJS (Direct P2P Worldwide DataChannel)
// Automatic fallback & dual routing for 100% reliable multiplayer across all devices

class NetworkManager {
  constructor() {
    this.peer = null;
    this.connection = null;
    this.isHost = false;
    this.roomCode = null;
    this.playerId = 'p_' + Math.random().toString(36).substring(2, 9);
    this.player = {
      name: 'Player',
      role: 'female', // 'female' (Queen 👸) or 'male' (King 🤴)
      avatar: '👸'
    };
    this.partner = null;
    this.connected = false;
    this.isSingleDevice = false;
    this.listeners = new Map();
    this.cppServerActive = false;
    this.pollInterval = null;
    this.heartbeatTimer = null;
    this.lastPartnerActivity = 0;

    // Check if C++ Server is running on backend
    this._checkCppServer();

    // Listen for tab/browser close or navigation away
    this._setupUnloadListeners();
  }

  _setupUnloadListeners() {
    const notifyExit = () => {
      if (this.connected && !this.isSingleDevice) {
        this.send('PARTNER_LEFT', { playerId: this.playerId });
        this.disconnect();
      }
    };

    window.addEventListener('beforeunload', notifyExit);
    window.addEventListener('pagehide', notifyExit);
  }

  async _checkCppServer() {
    try {
      const res = await fetch('/api/status', { method: 'GET' });
      if (res.ok) {
        const data = await res.json();
        if (data.status === 'ok') {
          this.cppServerActive = true;
          console.log('[TwoHearts] Native C++ Game Server Active:', data.engine);
        }
      }
    } catch (e) {
      this.cppServerActive = false;
    }
  }

  // Generate a cute memorable room code (e.g. LOVE24, ROSE82, SOUL35)
  generateRoomCode() {
    const words = ['LOVE', 'ROSE', 'SOUL', 'MOON', 'STAR', 'KISS', 'HEART', 'DUO', 'CUPID', 'BEAU'];
    const word = words[Math.floor(Math.random() * words.length)];
    const num = Math.floor(10 + Math.random() * 90);
    return `${word}${num}`;
  }

  // Register event callback
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
  }

  emit(event, data) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).forEach(cb => {
        try { cb(data); } catch (e) { console.error('Listener error:', e); }
      });
    }
  }

  // Create room (Host)
  createRoom(roomCode, playerProfile) {
    this.isHost = true;
    this.roomCode = roomCode.toUpperCase().trim();
    this.player = { ...playerProfile };
    this.isSingleDevice = false;

    // Notify C++ server if active
    if (this.cppServerActive) {
      fetch(`/api/room/create?code=${this.roomCode}&id=${this.playerId}&name=${encodeURIComponent(this.player.name)}&role=${this.player.role}`, { method: 'POST' }).catch(() => {});
      this._startCppPolling();
    }

    const hostPeerId = `twohearts-${this.roomCode.toLowerCase()}-host`;

    this._initPeer(hostPeerId, () => {
      this.emit('room_created', { roomCode: this.roomCode });
      
      // Wait for partner to join
      this.peer.on('connection', (conn) => {
        this.connection = conn;
        this._setupConnection();
      });
    });
  }

  // Join room (Guest)
  joinRoom(roomCode, playerProfile) {
    this.isHost = false;
    this.roomCode = roomCode.toUpperCase().trim();
    this.player = { ...playerProfile };
    this.isSingleDevice = false;

    // Notify C++ server if active
    if (this.cppServerActive) {
      fetch(`/api/room/join?code=${this.roomCode}&id=${this.playerId}&name=${encodeURIComponent(this.player.name)}&role=${this.player.role}`, { method: 'POST' })
        .then(r => r.json())
        .then(data => {
          if (data.success && data.partner) {
            this.partner = data.partner;
            this.connected = true;
            this.lastPartnerActivity = Date.now();
            this.emit('partner_connected', { partner: this.partner });
            this._startCppPolling();
            this._startHeartbeat();
          }
        }).catch(() => {});
    }

    const guestPeerId = `twohearts-${this.roomCode.toLowerCase()}-guest-${Math.floor(Math.random() * 1000)}`;
    const targetHostId = `twohearts-${this.roomCode.toLowerCase()}-host`;

    this._initPeer(guestPeerId, () => {
      this.emit('status', 'Connecting to partner...');
      const conn = this.peer.connect(targetHostId, {
        reliable: true
      });
      this.connection = conn;
      this._setupConnection();
    });
  }

  _startCppPolling() {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = setInterval(async () => {
      if (!this.roomCode || !this.connected) return;
      try {
        const res = await fetch(`/api/room/poll?code=${this.roomCode}&id=${this.playerId}`);
        if (res.ok) {
          const data = await res.json();
          if (data.messages && data.messages.length > 0) {
            data.messages.forEach(msg => {
              if (typeof msg === 'string') {
                try { msg = JSON.parse(msg); } catch (e) {}
              }
              this._handleIncomingData(msg);
            });
          }
        }
      } catch (e) {}
    }, 700);
  }

  _startHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.lastPartnerActivity = Date.now();

    this.heartbeatTimer = setInterval(() => {
      if (!this.connected || this.isSingleDevice) return;

      // Send heartbeat ping
      this.send('HEARTBEAT_PING', { t: Date.now() });

      // If no activity from partner for > 8.5 seconds, partner closed site or disconnected
      if (Date.now() - this.lastPartnerActivity > 8500) {
        console.warn('Heartbeat timeout: partner disconnected or closed the site.');
        this.disconnect();
      }
    }, 3000);
  }

  _initPeer(peerId, onSuccess) {
    if (typeof Peer === 'undefined') {
      if (this.cppServerActive) {
        this.emit('room_created', { roomCode: this.roomCode });
        return;
      }
      this.emit('error', 'Connecting via C++ Game Server...');
      return;
    }

    if (this.peer) {
      try { this.peer.destroy(); } catch (e) {}
    }

    this.peer = new Peer(peerId, {
      debug: 1,
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' },
          { urls: 'stun:global.stun.twilio.com:3478' }
        ]
      }
    });

    this.peer.on('open', (id) => {
      console.log('Peer connected with ID:', id);
      if (onSuccess) onSuccess(id);
    });

    this.peer.on('error', (err) => {
      console.warn('PeerJS warning:', err);
      if (err.type === 'peer-unavailable') {
        this.emit('error', `Room "${this.roomCode}" not found! Make sure your partner created the room first.`);
      } else if (err.type === 'unavailable-id') {
        this.emit('error', 'This room code is already active. Please try joining or use a new code.');
      }
    });
  }

  _setupConnection() {
    if (!this.connection) return;

    this.connection.on('open', () => {
      this.connected = true;
      this.lastPartnerActivity = Date.now();
      console.log('Direct WebRTC DataChannel established!');

      // Send local player profile & highest stage progress
      const currentLevel = (window.auth && typeof window.auth.getUnlockedLevel === 'function') 
        ? window.auth.getUnlockedLevel() 
        : 1;

      this.send('HANDSHAKE', {
        player: this.player,
        isHost: this.isHost,
        unlockedLevel: currentLevel
      });

      this._startHeartbeat();
    });

    this.connection.on('data', (data) => {
      this._handleIncomingData(data);
    });

    this.connection.on('close', () => {
      console.log('WebRTC connection closed by remote party.');
      this.disconnect();
    });

    this.connection.on('error', (err) => {
      console.error('Connection error:', err);
      this.disconnect();
    });
  }

  _handleIncomingData(msg) {
    if (!msg || typeof msg !== 'object') return;

    this.lastPartnerActivity = Date.now();
    const { type, payload } = msg;

    if (type === 'PARTNER_LEFT') {
      console.log('Partner explicitly closed the site or left.');
      this.disconnect();
      return;
    } else if (type === 'HEARTBEAT_PING') {
      this.send('HEARTBEAT_PONG', { t: payload.t });
      return;
    } else if (type === 'HEARTBEAT_PONG') {
      return;
    } else if (type === 'HANDSHAKE') {
      this.partner = payload.player;

      // Sync highest unlocked stage between partners across devices
      if (payload.unlockedLevel && window.auth && typeof window.auth.saveProgress === 'function') {
        const partnerLvl = parseInt(payload.unlockedLevel, 10);
        if (partnerLvl > window.auth.getUnlockedLevel()) {
          window.auth.saveProgress(partnerLvl);
        }
      }

      if (this.isHost) {
        const currentLevel = (window.auth && typeof window.auth.getUnlockedLevel === 'function') 
          ? window.auth.getUnlockedLevel() 
          : 1;
        this.send('HANDSHAKE_ACK', { 
          player: this.player,
          unlockedLevel: currentLevel
        });
      }
      this.emit('partner_connected', { partner: this.partner });
    } else if (type === 'HANDSHAKE_ACK') {
      this.partner = payload.player;

      // Sync highest unlocked stage between partners across devices
      if (payload.unlockedLevel && window.auth && typeof window.auth.saveProgress === 'function') {
        const partnerLvl = parseInt(payload.unlockedLevel, 10);
        if (partnerLvl > window.auth.getUnlockedLevel()) {
          window.auth.saveProgress(partnerLvl);
        }
      }

      this.emit('partner_connected', { partner: this.partner });
    } else {
      this.emit('message', { type, payload });
    }
  }

  send(type, payload = {}) {
    if (this.isSingleDevice) {
      setTimeout(() => {
        this.emit('message', { type, payload });
      }, 50);
      return true;
    }

    const packet = { type, payload };

    // 1. Send via direct WebRTC DataChannel
    let sent = false;
    if (this.connection && this.connected) {
      try {
        this.connection.send(packet);
        sent = true;
      } catch (e) {}
    }

    // 2. Also send via C++ Server relay if active
    if (this.cppServerActive && this.roomCode) {
      fetch(`/api/room/send?code=${this.roomCode}&id=${this.playerId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(packet)
      }).catch(() => {});
      sent = true;
    }

    return sent;
  }

  // Single Device / Pass & Play Fallback Mode
  enableSingleDeviceMode(playerProfile) {
    this.isSingleDevice = true;
    this.connected = true;
    this.player = { ...playerProfile };
    this.partner = {
      name: playerProfile.role === 'female' ? 'Him' : 'Her',
      role: playerProfile.role === 'female' ? 'male' : 'female',
      avatar: playerProfile.role === 'female' ? '🤴' : '👸'
    };
    this.emit('partner_connected', { partner: this.partner, isSingleDevice: true });
  }

  disconnect() {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
      this.pollInterval = null;
    }
    if (this.connection) {
      try { this.connection.close(); } catch (e) {}
      this.connection = null;
    }
    if (this.peer) {
      try { this.peer.destroy(); } catch (e) {}
      this.peer = null;
    }
    const wasConnected = this.connected;
    this.connected = false;
    this.partner = null;
    this.isSingleDevice = false;

    if (wasConnected) {
      this.emit('disconnected');
    }
  }
}

window.network = new NetworkManager();
