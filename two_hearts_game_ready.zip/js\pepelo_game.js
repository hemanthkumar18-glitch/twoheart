// Pepelo 3D Co-op Adventure Game Engine for TwoHearts
// A 3D Cooperative Puzzle-Platformer inspired by Pepelo / It Takes Two
// Built with Three.js - 60 FPS mobile-first controls & real-time WebRTC/C++ sync
// Features 20 Full Co-Op Levels with Hidden Hints, Level Select & Grand Finale!

class PepeloCoopGame {
  constructor() {
    this.container = null;
    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.clock = new THREE.Clock();

    this.localPlayer = null;
    this.remotePlayer = null;
    this.carriedObject = null;

    this.currentLevelIndex = 1;
    this.totalLevels = 20;
    this.levelObjects = [];
    this.platforms = [];
    this.pressurePlates = [];
    this.interactiveCubes = [];
    this.doors = [];
    this.elevators = [];
    this.portal = null;

    // Movement & Input
    this.keys = { w: false, a: false, s: false, d: false, space: false, e: false };
    this.joystick = { active: false, dx: 0, dy: 0, touchId: null };
    this.playerSpeed = 9.0;
    this.gravity = -26.0;
    this.jumpForce = 11.5;

    // Network Sync
    this.lastSyncTime = 0;
    this.syncRateMs = 50; // 20 updates per sec
    this.isLevelWon = false;
    this.isActive = false;
    this.isHintVisible = false;
  }

  init(containerId = 'pepelo-viewport') {
    this.container = document.getElementById(containerId);
    if (!this.container) return;

    this.isActive = true;
    this.isLevelWon = false;

    // 1. Scene Setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x120e2e);
    this.scene.fog = new THREE.FogExp2(0x120e2e, 0.015);

    // 2. Camera Setup (Isometric Third Person)
    const aspect = this.container.clientWidth / this.container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 200);
    this.camera.position.set(0, 16, 22);

    // 3. Renderer Setup
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Clear previous children
    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);

    // 4. Lighting
    const hemiLight = new THREE.HemisphereLight(0xffd1e8, 0x1f193f, 0.8);
    this.scene.add(hemiLight);

    const dirLight = new THREE.DirectionalLight(0xfff0f5, 1.2);
    dirLight.position.set(20, 30, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    const d = 25;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    this.scene.add(dirLight);

    const pinkPoint = new THREE.PointLight(0xff4d8d, 1.5, 30);
    pinkPoint.position.set(-10, 8, -5);
    this.scene.add(pinkPoint);

    const bluePoint = new THREE.PointLight(0x4d94ff, 1.5, 30);
    bluePoint.position.set(10, 8, -5);
    this.scene.add(bluePoint);

    // 5. Build Characters
    this.buildCharacters();

    // 6. Build Initial Level (Auto-resumes highest unlocked stage)
    if (window.auth && typeof window.auth.getUnlockedLevel === 'function') {
      this.currentLevelIndex = window.auth.getUnlockedLevel();
    }
    this.loadLevel(this.currentLevelIndex);

    // 7. Setup Inputs & Touch Controls
    this.setupInputListeners();
    this.setupVirtualJoystick();

    // 8. Network Listeners
    this.setupNetworkListeners();

    // Resize event
    window.addEventListener('resize', () => this.onWindowResize());

    // 9. Start Animation Loop
    this.animate();
  }

  // --- CHARACTER CREATION ---

  createExplorerModel(role = 'female', name = 'Player') {
    const group = new THREE.Group();
    const isFemale = (role === 'female');
    const mainColor = isFemale ? 0xff4d8d : 0x2979ff;
    const trimColor = isFemale ? 0xff758f : 0x70a1ff;
    const skinColor = 0xffdfc4;

    const bodyMat = new THREE.MeshStandardMaterial({ color: mainColor, roughness: 0.4 });
    const trimMat = new THREE.MeshStandardMaterial({ color: trimColor, roughness: 0.3 });
    const skinMat = new THREE.MeshStandardMaterial({ color: skinColor, roughness: 0.5 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x1f1933, roughness: 0.8 });
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
    const whiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    // Torso / Body
    const torsoGeo = new THREE.CylinderGeometry(0.55, 0.65, 1.1, 16);
    const torso = new THREE.Mesh(torsoGeo, bodyMat);
    torso.position.y = 1.1;
    torso.castShadow = true;
    group.add(torso);

    // Backpack
    const packGeo = new THREE.BoxGeometry(0.7, 0.7, 0.4);
    const backpack = new THREE.Mesh(packGeo, trimMat);
    backpack.position.set(0, 1.2, -0.45);
    backpack.castShadow = true;
    group.add(backpack);

    // Head
    const headGeo = new THREE.SphereGeometry(0.55, 16, 16);
    const head = new THREE.Mesh(headGeo, skinMat);
    head.position.y = 2.0;
    head.castShadow = true;
    group.add(head);

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.09, 8, 8);
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.18, 2.05, 0.48);
    group.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.18, 2.05, 0.48);
    group.add(rightEye);

    // Highlights
    const hiGeo = new THREE.SphereGeometry(0.03, 6, 6);
    const leftHi = new THREE.Mesh(hiGeo, whiteMat);
    leftHi.position.set(-0.16, 2.08, 0.55);
    group.add(leftHi);

    const rightHi = new THREE.Mesh(hiGeo, whiteMat);
    rightHi.position.set(0.20, 2.08, 0.55);
    group.add(rightHi);

    // Crown or Cap
    if (isFemale) {
      const crownGeo = new THREE.ConeGeometry(0.35, 0.35, 5);
      const crownMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.6, roughness: 0.2 });
      const crown = new THREE.Mesh(crownGeo, crownMat);
      crown.position.set(0, 2.6, 0);
      crown.rotation.x = Math.PI;
      group.add(crown);
    } else {
      const capGeo = new THREE.CylinderGeometry(0.65, 0.65, 0.15, 16);
      const cap = new THREE.Mesh(capGeo, trimMat);
      cap.position.set(0, 2.5, 0);
      group.add(cap);

      const brimGeo = new THREE.CylinderGeometry(0.8, 0.8, 0.05, 16);
      const brim = new THREE.Mesh(brimGeo, trimMat);
      brim.position.set(0, 2.45, 0.2);
      group.add(brim);
    }

    // Legs
    const legGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.6, 8);
    const leftLeg = new THREE.Mesh(legGeo, darkMat);
    leftLeg.position.set(-0.25, 0.3, 0);
    leftLeg.castShadow = true;
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, darkMat);
    rightLeg.position.set(0.25, 0.3, 0);
    rightLeg.castShadow = true;
    group.add(rightLeg);

    // Arms
    const armGeo = new THREE.CylinderGeometry(0.14, 0.14, 0.6, 8);
    const leftArm = new THREE.Mesh(armGeo, bodyMat);
    leftArm.position.set(-0.65, 1.2, 0);
    group.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, bodyMat);
    rightArm.position.set(0.65, 1.2, 0);
    group.add(rightArm);

    // Floating Name Tag
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = isFemale ? 'rgba(255, 77, 141, 0.85)' : 'rgba(41, 121, 255, 0.85)';
    ctx.roundRect(10, 10, 236, 44, 20);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.font = 'bold 24px Poppins, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText((isFemale ? '👸 ' : '🤴 ') + name, 128, 32);

    const spriteTex = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: spriteTex, depthTest: false });
    const nameSprite = new THREE.Sprite(spriteMat);
    nameSprite.position.set(0, 3.2, 0);
    nameSprite.scale.set(2.5, 0.62, 1);
    group.add(nameSprite);

    return {
      mesh: group,
      leftLeg: leftLeg,
      rightLeg: rightLeg,
      leftArm: leftArm,
      rightArm: rightArm,
      head: head,
      nameSprite: nameSprite,
      role: role,
      name: name,
      velocity: new THREE.Vector3(),
      isGrounded: false,
      isCarrying: false,
      walkCycle: 0
    };
  }

  buildCharacters() {
    const myRole = window.network.player.role || 'female';
    const myName = window.network.player.name || (myRole === 'female' ? 'Juliet' : 'Romeo');

    const partnerRole = (myRole === 'female') ? 'male' : 'female';
    const partnerName = window.network.partner?.name || (partnerRole === 'female' ? 'Juliet' : 'Romeo');

    this.localPlayer = this.createExplorerModel(myRole, myName);
    this.localPlayer.mesh.position.set(-3, 0, 8);
    this.scene.add(this.localPlayer.mesh);

    this.remotePlayer = this.createExplorerModel(partnerRole, partnerName);
    this.remotePlayer.mesh.position.set(3, 0, 8);
    this.scene.add(this.remotePlayer.mesh);
  }

  // --- LEVEL MANAGEMENT ---

  clearCurrentLevel() {
    this.levelObjects.forEach(obj => this.scene.remove(obj));
    this.levelObjects = [];
    this.platforms = [];
    this.pressurePlates = [];
    this.interactiveCubes = [];
    this.doors = [];
    this.elevators = [];
    this.portal = null;
  }

  loadLevel(levelNumber) {
    this.clearCurrentLevel();
    this.isLevelWon = false;
    this.currentLevelIndex = Math.max(1, Math.min(this.totalLevels, levelNumber));

    // Reset player positions
    if (this.localPlayer) {
      this.localPlayer.mesh.position.set(-3, 1, 8);
      this.localPlayer.velocity.set(0, 0, 0);
    }
    if (this.remotePlayer) {
      this.remotePlayer.mesh.position.set(3, 1, 8);
      this.remotePlayer.velocity.set(0, 0, 0);
    }

    // Load appropriate level
    switch(this.currentLevelIndex) {
      case 1: this.buildLevel1_TwinBridges(); break;
      case 2: this.buildLevel2_AncientElevator(); break;
      case 3: this.buildLevel3_SteppingStones(); break;
      case 4: this.buildLevel4_DoubleGate(); break;
      case 5: this.buildLevel5_CrystalLift(); break;
      case 6: this.buildLevel6_HeavyLifting(); break;
      case 7: this.buildLevel7_ColorResonance(); break;
      case 8: this.buildLevel8_LaserGrid(); break;
      case 9: this.buildLevel9_RotatingGears(); break;
      case 10: this.buildLevel10_SeesawBridge(); break;
      case 11: this.buildLevel11_SynchronizedSprint(); break;
      case 12: this.buildLevel12_ConveyorMaze(); break;
      case 13: this.buildLevel13_StarryCrossway(); break;
      case 14: this.buildLevel14_SkywardBouncers(); break;
      case 15: this.buildLevel15_CubeDomino(); break;
      case 16: this.buildLevel16_MirrorChamber(); break;
      case 17: this.buildLevel17_CloudSpire(); break;
      case 18: this.buildLevel18_DualLaserGauntlet(); break;
      case 19: this.buildLevel19_TrialOfTrust(); break;
      case 20: this.buildLevel20_EternalSanctuary(); break;
      default: this.buildLevel1_TwinBridges(); break;
    }

    this.updateInstructionBanner(this.currentLevelIndex);
  }

  // ==========================================
  // LEVEL BUILDERS (LEVELS 1 TO 20)
  // ==========================================

  // --- STAGE 1: The Twin Bridges ---
  buildLevel1_TwinBridges() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x3d316e, roughness: 0.6 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.5 });
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x2b2254, roughness: 0.7 });

    this.createPlatform(0, 0, 6, 12, 1, 10, groundMat);
    this.createPlatform(-7, 0, -4, 6, 1, 8, groundMat);
    this.createPlatform(7, 0, -4, 6, 1, 8, groundMat);
    this.createPlatform(0, 0, -12, 10, 1, 8, groundMat);

    const bridgeLeft = this.createMovableBridge(-4, 0, 0, 3, 0.4, 6, woodMat);
    bridgeLeft.mesh.position.y = -4;

    const bridgeRight = this.createMovableBridge(4, 0, 0, 3, 0.4, 6, woodMat);
    bridgeRight.mesh.position.y = -4;

    const mainDoor = this.createSlidingDoor(0, 1.5, -8, 6, 3, 0.8, wallMat);

    this.createPressurePlate(3.5, 0.55, 6, 0x4d94ff, (p) => { bridgeLeft.targetY = p ? 0.3 : -4; });
    this.createPressurePlate(-3.5, 0.55, 6, 0xff4d8d, (p) => { bridgeRight.targetY = p ? 0.3 : -4; });
    this.createCarryableCube(-7, 1.5, -4, 0xffd166);
    this.createPressurePlate(7, 0.55, -4, 0x06d6a0, (p) => { mainDoor.targetY = p ? -3.5 : 1.5; });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 2: The Ancient Elevator ---
  buildLevel2_AncientElevator() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x34295e, roughness: 0.6 });
    const liftMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.5, roughness: 0.3 });

    this.createPlatform(0, 0, 6, 14, 1, 10, groundMat);
    this.createPlatform(0, 5, -8, 14, 1, 10, groundMat);

    const elevator = this.createPlatform(-4, 0.3, -1, 4, 0.5, 4, liftMat);
    elevator.isElevator = true;
    elevator.targetY = 0.3;
    this.elevators.push(elevator);

    this.createPressurePlate(4, 0.55, 6, 0x4d94ff, (p) => { elevator.targetY = p ? 5.2 : 0.3; });

    const ramp = this.createPlatform(4, 2.5, -1, 3, 0.4, 7, groundMat);
    ramp.mesh.rotation.x = 0.5;
    ramp.mesh.position.y = -5;
    ramp.targetY = -5;

    this.createPressurePlate(-4, 5.55, -8, 0xff4d8d, (p) => { ramp.targetY = p ? 2.5 : -5; });

    this.createExitPortal(0, 6.2, -10);
    this.addFloatingClouds();
  }

  // --- STAGE 3: Stepping Stones ---
  buildLevel3_SteppingStones() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x221a42, roughness: 0.6 });
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x06d6a0, metalness: 0.3, roughness: 0.4 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -12, 12, 1, 8, groundMat);

    // 3 Floating Stepping Stones that freeze when button is held
    const s1 = this.createPlatform(-2.5, -4, 3, 2.5, 0.5, 2.5, stoneMat);
    const s2 = this.createPlatform(2.5, -4, 0, 2.5, 0.5, 2.5, stoneMat);
    const s3 = this.createPlatform(-1.5, -4, -4, 2.5, 0.5, 2.5, stoneMat);

    this.createPressurePlate(0, 0.55, 8, 0xffd166, (p) => {
      s1.targetY = p ? 0.3 : -4;
      s2.targetY = p ? 0.3 : -4;
      s3.targetY = p ? 0.3 : -4;
    });

    this.createCarryableCube(0, 1.5, 6, 0xff758f);
    this.createPressurePlate(0, 0.55, -12, 0x06d6a0, (p) => {});

    this.createExitPortal(0, 1.2, -14);
    this.addFloatingClouds();
  }

  // --- STAGE 4: The Double Gate ---
  buildLevel4_DoubleGate() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x2d1f4d, roughness: 0.6 });
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x1f1933, roughness: 0.8 });

    this.createPlatform(-4, 0, 0, 6, 1, 18, groundMat); // Queen corridor
    this.createPlatform(4, 0, 0, 6, 1, 18, groundMat);  // King corridor
    this.createPlatform(0, 0, 0, 1, 4, 18, wallMat);    // Middle divider wall

    const doorQueen = this.createSlidingDoor(-4, 1.5, -2, 5, 3, 0.5, wallMat);
    const doorKing = this.createSlidingDoor(4, 1.5, 2, 5, 3, 0.5, wallMat);

    // Queen presses button to open King's door; King presses button to open Queen's door
    this.createPressurePlate(-4, 0.55, 5, 0xff4d8d, (p) => { doorKing.targetY = p ? -3.5 : 1.5; });
    this.createPressurePlate(4, 0.55, -5, 0x4d94ff, (p) => { doorQueen.targetY = p ? -3.5 : 1.5; });

    this.createPlatform(0, 0, -12, 10, 1, 6, groundMat); // Joint portal platform
    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 5: The Crystal Lift ---
  buildLevel5_CrystalLift() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1a2a4f, roughness: 0.5 });
    const crystalMat = new THREE.MeshStandardMaterial({ color: 0x00f0ff, metalness: 0.6, roughness: 0.2 });

    this.createPlatform(0, 0, 8, 14, 1, 8, groundMat);
    this.createPlatform(0, 6, -10, 14, 1, 8, groundMat);

    // Two lifts: standing on one raises the other
    const liftA = this.createPlatform(-4, 0.3, -1, 3.5, 0.5, 3.5, crystalMat);
    const liftB = this.createPlatform(4, 0.3, -1, 3.5, 0.5, 3.5, crystalMat);
    this.elevators.push(liftA, liftB);

    this.createPressurePlate(-4, 0.55, 7, 0x00f0ff, (p) => { liftB.targetY = p ? 6.2 : 0.3; });
    this.createPressurePlate(4, 6.55, -9, 0xffd166, (p) => { liftA.targetY = p ? 6.2 : 0.3; });

    this.createExitPortal(0, 7.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 6: Heavy Lifting (Two Cubes) ---
  buildLevel6_HeavyLifting() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x221a42, roughness: 0.6 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.5 });

    this.createPlatform(0, 0, 6, 16, 1, 8, groundMat);
    this.createPlatform(0, 0, -10, 12, 1, 8, groundMat);

    const bridge = this.createMovableBridge(0, -4, -2, 6, 0.4, 8, woodMat);

    this.createCarryableCube(-5, 1.5, 6, 0xffd166);
    this.createCarryableCube(5, 1.5, 6, 0x06d6a0);

    let cubeAOnPlate = false;
    let cubeBOnPlate = false;

    this.createPressurePlate(-3, 0.55, 6, 0xffd166, (p) => {
      cubeAOnPlate = p;
      bridge.targetY = (cubeAOnPlate && cubeBOnPlate) ? 0.3 : -4;
    });

    this.createPressurePlate(3, 0.55, 6, 0x06d6a0, (p) => {
      cubeBOnPlate = p;
      bridge.targetY = (cubeAOnPlate && cubeBOnPlate) ? 0.3 : -4;
    });

    this.createExitPortal(0, 1.2, -10);
    this.addFloatingClouds();
  }

  // --- STAGE 7: Color Resonance ---
  buildLevel7_ColorResonance() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x2f1b40, roughness: 0.6 });
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x1f1933, roughness: 0.8 });

    this.createPlatform(0, 0, 8, 14, 1, 8, groundMat);
    this.createPlatform(0, 0, -8, 14, 1, 8, groundMat);

    const pinkGate = this.createSlidingDoor(-3, 1.5, 0, 4, 3, 0.5, wallMat);
    const blueGate = this.createSlidingDoor(3, 1.5, 0, 4, 3, 0.5, wallMat);

    this.createPressurePlate(-4, 0.55, 8, 0xff4d8d, (p) => { pinkGate.targetY = p ? -3.5 : 1.5; });
    this.createPressurePlate(4, 0.55, 8, 0x4d94ff, (p) => { blueGate.targetY = p ? -3.5 : 1.5; });

    this.createExitPortal(0, 1.2, -8);
    this.addFloatingClouds();
  }

  // --- STAGE 8: The Laser Grid ---
  buildLevel8_LaserGrid() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x192841, roughness: 0.6 });
    const redMat = new THREE.MeshStandardMaterial({ color: 0xff0055, emissive: 0xff0055, emissiveIntensity: 0.8 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -8, 12, 1, 8, groundMat);

    const pathway = this.createPlatform(0, 0, 0, 4, 0.5, 8, groundMat);

    // Glowing laser beam
    const laserGeo = new THREE.CylinderGeometry(0.08, 0.08, 6, 8);
    const laserMesh = new THREE.Mesh(laserGeo, redMat);
    laserMesh.rotation.z = Math.PI / 2;
    laserMesh.position.set(0, 1.2, 0);
    this.scene.add(laserMesh);
    this.levelObjects.push(laserMesh);

    this.createPressurePlate(-3, 0.55, 8, 0x06d6a0, (p) => {
      laserMesh.position.y = p ? -10 : 1.2; // Laser turns off!
    });

    this.createExitPortal(0, 1.2, -8);
    this.addFloatingClouds();
  }

  // --- STAGE 9: The Rotating Gears ---
  buildLevel9_RotatingGears() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.6 });
    const gearMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.7, roughness: 0.3 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -10, 12, 1, 8, groundMat);

    const gearA = this.createPlatform(-2.5, 0.3, 0, 4, 0.4, 4, gearMat);
    const gearB = this.createPlatform(2.5, 0.3, -4, 4, 0.4, 4, gearMat);

    this.createPressurePlate(0, 0.55, 8, 0xffd166, (p) => {});
    this.createExitPortal(0, 1.2, -10);
    this.addFloatingClouds();
  }

  // --- STAGE 10: The Seesaw Bridge ---
  buildLevel10_SeesawBridge() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x251c38, roughness: 0.6 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0xb5835a, roughness: 0.4 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -10, 12, 1, 8, groundMat);

    // Balanced tilting beam
    const seesaw = this.createPlatform(0, 0.3, -1, 5, 0.4, 10, woodMat);

    this.createCarryableCube(0, 1.5, 6, 0xff4d8d);
    this.createExitPortal(0, 1.2, -10);
    this.addFloatingClouds();
  }

  // --- STAGE 11: Synchronized Sprint (Dual Timed Plates) ---
  buildLevel11_SynchronizedSprint() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1f2440, roughness: 0.6 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.6, roughness: 0.3 });

    this.createPlatform(-7, 0, 0, 6, 1, 16, groundMat);
    this.createPlatform(7, 0, 0, 6, 1, 16, groundMat);
    this.createPlatform(0, 0, -12, 10, 1, 8, goldMat);

    const bridge = this.createMovableBridge(0, -5, -4, 8, 0.4, 8, goldMat);

    let p1 = false, p2 = false;
    this.createPressurePlate(-7, 0.55, 6, 0xff4d8d, (pressed) => {
      p1 = pressed;
      if (p1 && p2) bridge.targetY = 0.3;
      else bridge.targetY = -5;
    });

    this.createPressurePlate(7, 0.55, 6, 0x4d94ff, (pressed) => {
      p2 = pressed;
      if (p1 && p2) bridge.targetY = 0.3;
      else bridge.targetY = -5;
    });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 12: The Conveyor Maze ---
  buildLevel12_ConveyorMaze() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1b2838, roughness: 0.6 });
    const blueMat = new THREE.MeshStandardMaterial({ color: 0x2679ff, roughness: 0.4 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -10, 12, 1, 8, groundMat);

    const platform = this.createPlatform(0, 0.3, -1, 4, 0.4, 8, blueMat);

    this.createPressurePlate(0, 0.55, 8, 0x06d6a0, (p) => {
      platform.targetY = p ? 0.3 : -4;
    });

    this.createExitPortal(0, 1.2, -10);
    this.addFloatingClouds();
  }

  // --- STAGE 13: Starry Crossway ---
  buildLevel13_StarryCrossway() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x221338, roughness: 0.5 });
    const starMat = new THREE.MeshStandardMaterial({ color: 0x9d4edd, metalness: 0.5, roughness: 0.3 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(-6, 0, -4, 6, 1, 6, groundMat);
    this.createPlatform(6, 0, -4, 6, 1, 6, groundMat);
    this.createPlatform(0, 0, -12, 10, 1, 8, starMat);

    const bridgeA = this.createMovableBridge(-3, -4, 2, 4, 0.4, 6, starMat);
    const bridgeB = this.createMovableBridge(3, -4, 2, 4, 0.4, 6, starMat);

    this.createPressurePlate(3, 0.55, 8, 0xff4d8d, (p) => { bridgeA.targetY = p ? 0.3 : -4; });
    this.createPressurePlate(-3, 0.55, 8, 0x4d94ff, (p) => { bridgeB.targetY = p ? 0.3 : -4; });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 14: The Skyward Bouncers ---
  buildLevel14_SkywardBouncers() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1f1633, roughness: 0.6 });
    const goldMat = new THREE.MeshStandardMaterial({ color: 0xffd166, roughness: 0.3 });

    this.createPlatform(0, 0, 6, 14, 1, 10, groundMat);
    this.createPlatform(0, 6, -8, 14, 1, 10, goldMat);

    const lift = this.createPlatform(0, 0.3, -1, 4, 0.4, 4, goldMat);
    this.elevators.push(lift);

    this.createPressurePlate(0, 0.55, 7, 0xffd166, (p) => { lift.targetY = p ? 6.2 : 0.3; });
    this.createExitPortal(0, 7.2, -8);
    this.addFloatingClouds();
  }

  // --- STAGE 15: Cube Domino ---
  buildLevel15_CubeDomino() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x2b1c40, roughness: 0.6 });
    const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.7, roughness: 0.3 });

    this.createPlatform(0, 0, 8, 16, 1, 8, groundMat);
    this.createPlatform(0, 0, -12, 12, 1, 8, groundMat);

    const bridge = this.createMovableBridge(0, -5, -2, 6, 0.4, 10, bridgeMat);

    this.createCarryableCube(-5, 1.5, 8, 0xff4d8d);
    this.createCarryableCube(5, 1.5, 8, 0x4d94ff);

    let p1 = false, p2 = false;
    this.createPressurePlate(-2.5, 0.55, 8, 0xff4d8d, (p) => {
      p1 = p;
      bridge.targetY = (p1 && p2) ? 0.3 : -5;
    });

    this.createPressurePlate(2.5, 0.55, 8, 0x4d94ff, (p) => {
      p2 = p;
      bridge.targetY = (p1 && p2) ? 0.3 : -5;
    });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 16: The Mirror Chamber ---
  buildLevel16_MirrorChamber() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1b2848, roughness: 0.5 });
    const mirrorMat = new THREE.MeshStandardMaterial({ color: 0x06d6a0, metalness: 0.6, roughness: 0.2 });

    this.createPlatform(-6, 0, 0, 7, 1, 16, groundMat);
    this.createPlatform(6, 0, 0, 7, 1, 16, groundMat);
    this.createPlatform(0, 0, -12, 10, 1, 8, mirrorMat);

    const bridge = this.createMovableBridge(0, -5, -4, 6, 0.4, 8, mirrorMat);

    let m1 = false, m2 = false;
    this.createPressurePlate(-6, 0.55, 0, 0x06d6a0, (p) => {
      m1 = p;
      bridge.targetY = (m1 && m2) ? 0.3 : -5;
    });

    this.createPressurePlate(6, 0.55, 0, 0x06d6a0, (p) => {
      m2 = p;
      bridge.targetY = (m1 && m2) ? 0.3 : -5;
    });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 17: The Cloud Spire ---
  buildLevel17_CloudSpire() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x251c38, roughness: 0.6 });
    const spireMat = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.7, roughness: 0.3 });

    this.createPlatform(0, 0, 8, 14, 1, 8, groundMat);
    this.createPlatform(0, 4, 0, 12, 1, 6, groundMat);
    this.createPlatform(0, 8, -8, 12, 1, 8, spireMat);

    const lift1 = this.createPlatform(-4, 0.3, 4, 3, 0.4, 3, spireMat);
    const lift2 = this.createPlatform(4, 4.3, -4, 3, 0.4, 3, spireMat);
    this.elevators.push(lift1, lift2);

    this.createPressurePlate(4, 0.55, 8, 0x4d94ff, (p) => { lift1.targetY = p ? 4.2 : 0.3; });
    this.createPressurePlate(-3, 4.55, 0, 0xff4d8d, (p) => { lift2.targetY = p ? 8.2 : 4.3; });

    this.createExitPortal(0, 9.2, -8);
    this.addFloatingClouds();
  }

  // --- STAGE 18: Dual Laser Gauntlet ---
  buildLevel18_DualLaserGauntlet() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x1f1330, roughness: 0.6 });
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x120a1f, roughness: 0.8 });

    this.createPlatform(0, 0, 8, 14, 1, 8, groundMat);
    this.createPlatform(0, 0, -8, 14, 1, 8, groundMat);

    const gate1 = this.createSlidingDoor(-3, 1.5, 0, 4, 3, 0.5, wallMat);
    const gate2 = this.createSlidingDoor(3, 1.5, 0, 4, 3, 0.5, wallMat);

    this.createPressurePlate(-4, 0.55, 8, 0xff4d8d, (p) => { gate2.targetY = p ? -3.5 : 1.5; });
    this.createPressurePlate(4, 0.55, 8, 0x4d94ff, (p) => { gate1.targetY = p ? -3.5 : 1.5; });

    this.createExitPortal(0, 1.2, -8);
    this.addFloatingClouds();
  }

  // --- STAGE 19: The Trial of Trust ---
  buildLevel19_TrialOfTrust() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x161329, roughness: 0.6 });
    const glassMat = new THREE.MeshStandardMaterial({ color: 0xff85b3, transparent: true, opacity: 0.4, roughness: 0.1 });

    this.createPlatform(0, 0, 8, 12, 1, 8, groundMat);
    this.createPlatform(0, 0, -12, 12, 1, 8, groundMat);

    const bridge = this.createMovableBridge(0, -6, -2, 5, 0.4, 10, glassMat);

    this.createPressurePlate(0, 0.55, 8, 0xff4d8d, (p) => {
      bridge.targetY = p ? 0.3 : -6;
      bridge.mesh.material.opacity = p ? 0.85 : 0.1;
    });

    this.createExitPortal(0, 1.2, -12);
    this.addFloatingClouds();
  }

  // --- STAGE 20: The Eternal Sanctuary (GRAND FINALE!) ---
  buildLevel20_EternalSanctuary() {
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x2b153b, roughness: 0.5 });
    const royalGold = new THREE.MeshStandardMaterial({ color: 0xffd166, metalness: 0.8, roughness: 0.2 });
    const roseGold = new THREE.MeshStandardMaterial({ color: 0xff758f, metalness: 0.6, roughness: 0.3 });

    // Grand Floating Heart Sanctuary
    this.createPlatform(0, 0, 8, 16, 1, 8, groundMat);
    this.createPlatform(0, 4, -8, 16, 1, 10, royalGold);

    const grandBridge = this.createMovableBridge(0, -6, 0, 6, 0.5, 8, roseGold);

    this.createCarryableCube(-5, 1.5, 8, 0xffd166);
    this.createCarryableCube(5, 1.5, 8, 0xff4d8d);

    let pA = false, pB = false;
    this.createPressurePlate(-4, 0.55, 8, 0xff4d8d, (p) => {
      pA = p;
      grandBridge.targetY = (pA && pB) ? 2.0 : -6;
    });

    this.createPressurePlate(4, 0.55, 8, 0x4d94ff, (p) => {
      pB = p;
      grandBridge.targetY = (pA && pB) ? 2.0 : -6;
    });

    // Grand Crowned Heart Vortex (Giant Scale 3.2!)
    this.createExitPortal(0, 5.5, -8, 3.2);
    this.addFloatingClouds();
  }

  // --- PRIMITIVES & PUZZLE HELPERS ---

  createPlatform(x, y, z, w, h, d, material) {
    const geo = new THREE.BoxGeometry(w, h, d);
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(x, y, z);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    this.scene.add(mesh);
    this.levelObjects.push(mesh);

    const platform = { mesh, w, h, d, targetY: y };
    this.platforms.push(platform);
    return platform;
  }

  createMovableBridge(x, y, z, w, h, d, material) {
    const bridge = this.createPlatform(x, y, z, w, h, d, material);
    bridge.isBridge = true;
    return bridge;
  }

  createSlidingDoor(x, y, z, w, h, d, material) {
    const geo = new THREE.BoxGeometry(w, h, d);
    const mesh = new THREE.Mesh(geo, material);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    this.levelObjects.push(mesh);

    const door = { mesh, targetY: y, initialY: y };
    this.doors.push(door);
    return door;
  }

  createPressurePlate(x, y, z, color, onToggle) {
    const group = new THREE.Group();
    group.position.set(x, y, z);

    const baseGeo = new THREE.CylinderGeometry(1.2, 1.25, 0.15, 24);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x1f1933, roughness: 0.8 });
    const base = new THREE.Mesh(baseGeo, baseMat);
    group.add(base);

    const btnGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.25, 24);
    const btnMat = new THREE.MeshStandardMaterial({ color: color, roughness: 0.3, emissive: color, emissiveIntensity: 0.2 });
    const btn = new THREE.Mesh(btnGeo, btnMat);
    btn.position.y = 0.1;
    group.add(btn);

    this.scene.add(group);
    this.levelObjects.push(group);

    const plate = {
      group,
      btn,
      x, y, z,
      radius: 1.2,
      isPressed: false,
      onToggle: onToggle,
      color: color
    };
    this.pressurePlates.push(plate);
    return plate;
  }

  createCarryableCube(x, y, z, color) {
    const geo = new THREE.BoxGeometry(1.1, 1.1, 1.1);
    const mat = new THREE.MeshStandardMaterial({
      color: color,
      roughness: 0.3,
      emissive: color,
      emissiveIntensity: 0.25
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    this.levelObjects.push(mesh);

    const cube = {
      mesh,
      isCarried: false,
      carrier: null,
      id: 'cube_' + Math.floor(Math.random() * 1000)
    };
    this.interactiveCubes.push(cube);
    return cube;
  }

  createExitPortal(x, y, z, scale = 1.8) {
    const group = new THREE.Group();
    group.position.set(x, y, z);

    const ringGeo = new THREE.TorusGeometry(scale, 0.12, 16, 32);
    const ringMat = new THREE.MeshStandardMaterial({
      color: 0xffd166,
      emissive: 0xff9e00,
      emissiveIntensity: 0.8,
      metalness: 0.7
    });
    const ring1 = new THREE.Mesh(ringGeo, ringMat);
    group.add(ring1);

    const ring2 = new THREE.Mesh(ringGeo, new THREE.MeshStandardMaterial({
      color: 0xff4d8d,
      emissive: 0xff2b76,
      emissiveIntensity: 0.8
    }));
    ring2.rotation.x = Math.PI / 3;
    group.add(ring2);

    const coreGeo = new THREE.SphereGeometry(scale * 0.4, 16, 16);
    const coreMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const core = new THREE.Mesh(coreGeo, coreMat);
    group.add(core);

    this.scene.add(group);
    this.levelObjects.push(group);

    this.portal = { group, ring1, ring2, core, x, y, z, radius: scale * 1.5 };
  }

  addFloatingClouds() {
    const cloudMat = new THREE.MeshBasicMaterial({ color: 0x473b7b, transparent: true, opacity: 0.35 });
    for (let i = 0; i < 8; i++) {
      const geo = new THREE.DodecahedronGeometry(2.5 + Math.random() * 2);
      const cloud = new THREE.Mesh(geo, cloudMat);
      cloud.position.set((Math.random() - 0.5) * 45, -6 - Math.random() * 4, (Math.random() - 0.5) * 45);
      this.scene.add(cloud);
      this.levelObjects.push(cloud);
    }
  }

  // --- INPUT CONTROLS ---

  setupInputListeners() {
    window.addEventListener('keydown', (e) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') this.keys.w = true;
      if (k === 'a' || k === 'arrowleft') this.keys.a = true;
      if (k === 's' || k === 'arrowdown') this.keys.s = true;
      if (k === 'd' || k === 'arrowright') this.keys.d = true;
      if (k === ' ' || k === 'spacebar') {
        this.keys.space = true;
        this.handleJump();
      }
      if (k === 'e' || k === 'f') {
        this.handleAction();
      }
    });

    window.addEventListener('keyup', (e) => {
      const k = e.key.toLowerCase();
      if (k === 'w' || k === 'arrowup') this.keys.w = false;
      if (k === 'a' || k === 'arrowleft') this.keys.a = false;
      if (k === 's' || k === 'arrowdown') this.keys.s = false;
      if (k === 'd' || k === 'arrowright') this.keys.d = false;
      if (k === ' ' || k === 'spacebar') this.keys.space = false;
    });
  }

  setupVirtualJoystick() {
    const zone = document.getElementById('pepelo-joystick-zone');
    const thumb = document.getElementById('pepelo-joystick-thumb');
    if (!zone || !thumb) return;

    const maxRadius = 45;
    let startX = 0, startY = 0;

    const onTouchStart = (e) => {
      e.preventDefault();
      const touch = e.changedTouches[0];
      this.joystick.active = true;
      this.joystick.touchId = touch.identifier;
      const rect = zone.getBoundingClientRect();
      startX = rect.left + rect.width / 2;
      startY = rect.top + rect.height / 2;
    };

    const onTouchMove = (e) => {
      if (!this.joystick.active) return;
      e.preventDefault();
      for (let i = 0; i < e.changedTouches.length; i++) {
        const touch = e.changedTouches[i];
        if (touch.identifier === this.joystick.touchId) {
          const dx = touch.clientX - startX;
          const dy = touch.clientY - startY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          const angle = Math.atan2(dy, dx);
          const clampedDist = Math.min(dist, maxRadius);

          const thumbX = Math.cos(angle) * clampedDist;
          const thumbY = Math.sin(angle) * clampedDist;

          thumb.style.transform = `translate(${thumbX}px, ${thumbY}px)`;
          this.joystick.dx = thumbX / maxRadius;
          this.joystick.dy = thumbY / maxRadius;
          break;
        }
      }
    };

    const onTouchEnd = (e) => {
      for (let i = 0; i < e.changedTouches.length; i++) {
        if (e.changedTouches[i].identifier === this.joystick.touchId) {
          this.joystick.active = false;
          this.joystick.dx = 0;
          this.joystick.dy = 0;
          thumb.style.transform = `translate(0px, 0px)`;
          break;
        }
      }
    };

    zone.addEventListener('touchstart', onTouchStart, { passive: false });
    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onTouchEnd);
    window.addEventListener('touchcancel', onTouchEnd);
  }

  handleJump() {
    if (!this.localPlayer || !this.localPlayer.isGrounded) return;
    this.localPlayer.velocity.y = this.jumpForce;
    this.localPlayer.isGrounded = false;
    window.soundFx.playPop();
  }

  handleAction() {
    if (!this.localPlayer) return;

    if (this.carriedObject) {
      this.dropCarriedObject();
      return;
    }

    const pPos = this.localPlayer.mesh.position;
    for (const cube of this.interactiveCubes) {
      if (cube.isCarried) continue;
      const dist = pPos.distanceTo(cube.mesh.position);
      if (dist < 2.5) {
        this.pickUpCube(cube);
        break;
      }
    }
  }

  pickUpCube(cube) {
    this.carriedObject = cube;
    cube.isCarried = true;
    cube.carrier = this.localPlayer;
    window.soundFx.playPop();

    window.network.send('PEP_CUBE_PICK', {
      cubeId: cube.id,
      playerId: window.network.player.role
    });
  }

  dropCarriedObject() {
    if (!this.carriedObject) return;
    const cube = this.carriedObject;
    this.carriedObject = null;
    cube.isCarried = false;
    cube.carrier = null;

    const p = this.localPlayer.mesh;
    const dropOffset = new THREE.Vector3(0, 0, 1.2).applyQuaternion(p.quaternion);
    cube.mesh.position.copy(p.position).add(dropOffset);
    cube.mesh.position.y = Math.max(0.6, p.position.y);

    window.soundFx.playPop();

    window.network.send('PEP_CUBE_DROP', {
      cubeId: cube.id,
      x: cube.mesh.position.x,
      y: cube.mesh.position.y,
      z: cube.mesh.position.z
    });
  }

  // --- NETWORK SYNC ---

  setupNetworkListeners() {
    window.network.on('message', ({ type, payload }) => {
      if (!this.isActive) return;

      if (type === 'PEP_POS' && this.remotePlayer) {
        this.remotePlayer.targetPos = new THREE.Vector3(payload.x, payload.y, payload.z);
        this.remotePlayer.targetRotY = payload.rotY;
        this.remotePlayer.isCarrying = payload.isCarrying;
        this.remotePlayer.walkCycle = payload.walkCycle;
      } else if (type === 'PEP_CUBE_PICK') {
        const cube = this.interactiveCubes.find(c => c.id === payload.cubeId);
        if (cube && this.remotePlayer) {
          cube.isCarried = true;
          cube.carrier = this.remotePlayer;
        }
      } else if (type === 'PEP_CUBE_DROP') {
        const cube = this.interactiveCubes.find(c => c.id === payload.cubeId);
        if (cube) {
          cube.isCarried = false;
          cube.carrier = null;
          cube.mesh.position.set(payload.x, payload.y, payload.z);
        }
      } else if (type === 'PEP_LEVEL_NEXT') {
        this.currentLevelIndex = payload.level;
        this.loadLevel(this.currentLevelIndex);
      }
    });
  }

  broadcastLocalState() {
    const now = performance.now();
    if (now - this.lastSyncTime < this.syncRateMs || !this.localPlayer) return;
    this.lastSyncTime = now;

    const p = this.localPlayer.mesh;
    window.network.send('PEP_POS', {
      x: p.position.x,
      y: p.position.y,
      z: p.position.z,
      rotY: p.rotation.y,
      isCarrying: (this.carriedObject !== null),
      walkCycle: this.localPlayer.walkCycle
    });
  }

  // --- GAME ANIMATION & PHYSICS ---

  animate() {
    if (!this.isActive) return;
    requestAnimationFrame(() => this.animate());

    const delta = Math.min(this.clock.getDelta(), 0.1);

    this.updateLocalPlayer(delta);
    this.updateRemotePlayer(delta);
    this.updatePuzzles(delta);
    this.updateCamera();
    this.checkGoalPortal();
    this.broadcastLocalState();

    this.renderer.render(this.scene, this.camera);
  }

  updateLocalPlayer(delta) {
    if (!this.localPlayer) return;
    const p = this.localPlayer;

    let moveX = 0;
    let moveZ = 0;

    if (this.keys.w) moveZ -= 1;
    if (this.keys.s) moveZ += 1;
    if (this.keys.a) moveX -= 1;
    if (this.keys.d) moveX += 1;

    if (this.joystick.active) {
      moveX += this.joystick.dx;
      moveZ += this.joystick.dy;
    }

    const len = Math.sqrt(moveX * moveX + moveZ * moveZ);
    const isMoving = len > 0.05;

    if (isMoving) {
      const normX = moveX / Math.max(1, len);
      const normZ = moveZ / Math.max(1, len);

      p.mesh.position.x += normX * this.playerSpeed * delta;
      p.mesh.position.z += normZ * this.playerSpeed * delta;

      const targetAngle = Math.atan2(normX, normZ);
      p.mesh.rotation.y = THREE.MathUtils.lerp(p.mesh.rotation.y, targetAngle, 0.25);

      p.walkCycle += delta * 14;
      p.leftLeg.rotation.x = Math.sin(p.walkCycle) * 0.6;
      p.rightLeg.rotation.x = -Math.sin(p.walkCycle) * 0.6;
      p.leftArm.rotation.x = -Math.sin(p.walkCycle) * 0.6;
      p.rightArm.rotation.x = Math.sin(p.walkCycle) * 0.6;
    } else {
      p.leftLeg.rotation.x = THREE.MathUtils.lerp(p.leftLeg.rotation.x, 0, 0.2);
      p.rightLeg.rotation.x = THREE.MathUtils.lerp(p.rightLeg.rotation.x, 0, 0.2);
      p.leftArm.rotation.x = THREE.MathUtils.lerp(p.leftArm.rotation.x, 0, 0.2);
      p.rightArm.rotation.x = THREE.MathUtils.lerp(p.rightArm.rotation.x, 0, 0.2);
    }

    p.velocity.y += this.gravity * delta;
    p.mesh.position.y += p.velocity.y * delta;

    p.isGrounded = false;
    const feetY = p.mesh.position.y;
    const px = p.mesh.position.x;
    const pz = p.mesh.position.z;

    for (const plat of this.platforms) {
      const top = plat.mesh.position.y + plat.h / 2;
      const hw = plat.w / 2 + 0.4;
      const hd = plat.d / 2 + 0.4;

      if (px >= plat.mesh.position.x - hw && px <= plat.mesh.position.x + hw &&
          pz >= plat.mesh.position.z - hd && pz <= plat.mesh.position.z + hd) {
        if (feetY <= top + 0.2 && feetY >= top - 0.8 && p.velocity.y <= 0) {
          p.mesh.position.y = top;
          p.velocity.y = 0;
          p.isGrounded = true;
          break;
        }
      }
    }

    if (p.mesh.position.y < -12) {
      p.mesh.position.set(0, 3, 6);
      p.velocity.set(0, 0, 0);
      window.soundFx.playOops();
    }

    if (this.carriedObject) {
      this.carriedObject.mesh.position.set(
        p.mesh.position.x,
        p.mesh.position.y + 2.3,
        p.mesh.position.z
      );
      this.carriedObject.mesh.rotation.y = p.mesh.rotation.y;
    }
  }

  updateRemotePlayer(delta) {
    if (!this.remotePlayer) return;
    const rp = this.remotePlayer;

    if (rp.targetPos) rp.mesh.position.lerp(rp.targetPos, 0.3);
    if (rp.targetRotY !== undefined) rp.mesh.rotation.y = THREE.MathUtils.lerp(rp.mesh.rotation.y, rp.targetRotY, 0.3);

    if (rp.walkCycle !== undefined) {
      rp.leftLeg.rotation.x = Math.sin(rp.walkCycle) * 0.6;
      rp.rightLeg.rotation.x = -Math.sin(rp.walkCycle) * 0.6;
      rp.leftArm.rotation.x = -Math.sin(rp.walkCycle) * 0.6;
      rp.rightArm.rotation.x = Math.sin(rp.walkCycle) * 0.6;
    }

    const remoteCarriedCube = this.interactiveCubes.find(c => c.carrier === rp);
    if (remoteCarriedCube) {
      remoteCarriedCube.mesh.position.set(
        rp.mesh.position.x,
        rp.mesh.position.y + 2.3,
        rp.mesh.position.z
      );
    }
  }

  updatePuzzles(delta) {
    for (const plat of this.platforms) {
      if (plat.targetY !== undefined) {
        plat.mesh.position.y = THREE.MathUtils.lerp(plat.mesh.position.y, plat.targetY, delta * 4);
      }
    }

    for (const door of this.doors) {
      if (door.targetY !== undefined) {
        door.mesh.position.y = THREE.MathUtils.lerp(door.mesh.position.y, door.targetY, delta * 4);
      }
    }

    for (const plate of this.pressurePlates) {
      let isPressed = false;

      if (this.localPlayer) {
        const d = this.localPlayer.mesh.position.distanceTo(plate.group.position);
        if (d < plate.radius && Math.abs(this.localPlayer.mesh.position.y - plate.y) < 1.2) {
          isPressed = true;
        }
      }

      if (this.remotePlayer) {
        const d = this.remotePlayer.mesh.position.distanceTo(plate.group.position);
        if (d < plate.radius && Math.abs(this.remotePlayer.mesh.position.y - plate.y) < 1.2) {
          isPressed = true;
        }
      }

      for (const cube of this.interactiveCubes) {
        if (!cube.isCarried) {
          const d = cube.mesh.position.distanceTo(plate.group.position);
          if (d < plate.radius) {
            isPressed = true;
            break;
          }
        }
      }

      if (isPressed !== plate.isPressed) {
        plate.isPressed = isPressed;
        plate.btn.position.y = isPressed ? -0.05 : 0.1;
        plate.btn.material.emissiveIntensity = isPressed ? 0.9 : 0.2;
        if (isPressed) {
          window.soundFx.playPop();
        }
        if (plate.onToggle) plate.onToggle(isPressed);
      }
    }

    if (this.portal) {
      this.portal.ring1.rotation.z += delta * 1.5;
      this.portal.ring2.rotation.y += delta * 1.2;
    }
  }

  updateCamera() {
    if (!this.localPlayer) return;
    const p = this.localPlayer.mesh.position;

    const targetCamX = p.x;
    const targetCamY = p.y + 14;
    const targetCamZ = p.z + 18;

    this.camera.position.x = THREE.MathUtils.lerp(this.camera.position.x, targetCamX, 0.08);
    this.camera.position.y = THREE.MathUtils.lerp(this.camera.position.y, targetCamY, 0.08);
    this.camera.position.z = THREE.MathUtils.lerp(this.camera.position.z, targetCamZ, 0.08);

    this.camera.lookAt(p.x, p.y + 1.2, p.z);
  }

  checkGoalPortal() {
    if (!this.portal || this.isLevelWon || !this.localPlayer) return;

    const portalPos = new THREE.Vector3(this.portal.x, this.portal.y, this.portal.z);
    const dLocal = this.localPlayer.mesh.position.distanceTo(portalPos);

    let bothAtPortal = false;
    if (window.network.isSingleDevice) {
      bothAtPortal = (dLocal < this.portal.radius);
    } else if (this.remotePlayer) {
      const dRemote = this.remotePlayer.mesh.position.distanceTo(portalPos);
      bothAtPortal = (dLocal < this.portal.radius && dRemote < this.portal.radius);
    }

    if (bothAtPortal) {
      this.triggerLevelVictory();
    }
  }

  triggerLevelVictory() {
    this.isLevelWon = true;
    window.soundFx.playFanfare();
    window.app.triggerConfetti(100);

    // Save unlocked progress to couple account & storage
    if (window.auth && typeof window.auth.saveProgress === 'function') {
      window.auth.saveProgress(this.currentLevelIndex + 1);
    }

    if (this.currentLevelIndex >= this.totalLevels) {
      // Grand Finale Modal
      const finaleModal = document.getElementById('pepelo-finale-modal');
      if (finaleModal) finaleModal.style.display = 'flex';
    } else {
      const modal = document.getElementById('pepelo-win-modal');
      const winTitle = document.getElementById('pepelo-win-stage-num');
      if (winTitle) winTitle.textContent = `Stage ${this.currentLevelIndex} of ${this.totalLevels} Cleared!`;
      if (modal) modal.style.display = 'flex';
    }
  }

  nextLevel() {
    window.soundFx.playPop();
    const modal = document.getElementById('pepelo-win-modal');
    if (modal) modal.style.display = 'none';

    this.currentLevelIndex++;
    if (this.currentLevelIndex > this.totalLevels) {
      this.currentLevelIndex = 1;
    }

    this.loadLevel(this.currentLevelIndex);
    window.network.send('PEP_LEVEL_NEXT', { level: this.currentLevelIndex });
  }

  jumpToLevel(level) {
    window.soundFx.playPop();
    this.closeLevelSelect();
    this.currentLevelIndex = level;
    this.loadLevel(this.currentLevelIndex);
    window.network.send('PEP_LEVEL_NEXT', { level: this.currentLevelIndex });
  }

  openLevelSelect() {
    window.soundFx.playPop();
    const modal = document.getElementById('pepelo-select-modal');
    if (modal) {
      this.renderLevelGrid();
      modal.style.display = 'flex';
    }
  }

  closeLevelSelect() {
    window.soundFx.playPop();
    const modal = document.getElementById('pepelo-select-modal');
    if (modal) modal.style.display = 'none';
  }

  renderLevelGrid() {
    const grid = document.getElementById('pepelo-level-grid');
    if (!grid) return;

    grid.innerHTML = '';
    const levelNames = [
      "Twin Bridges", "The Elevator", "Stepping Stones", "Double Gate",
      "Crystal Lift", "Heavy Lifting", "Color Resonance", "Laser Grid",
      "Rotating Gears", "Seesaw Bridge", "Sync Sprint", "Conveyor Maze",
      "Starry Crossway", "Sky Bouncers", "Cube Domino", "Mirror Chamber",
      "Cloud Spire", "Laser Gauntlet", "Trial of Trust", "Eternal Sanctuary"
    ];

    const highestUnlocked = (window.auth && typeof window.auth.getUnlockedLevel === 'function')
      ? window.auth.getUnlockedLevel()
      : 1;

    for (let i = 1; i <= this.totalLevels; i++) {
      const isCurrent = (i === this.currentLevelIndex);
      const isUnlocked = (i <= highestUnlocked);
      const isCompleted = (i < highestUnlocked);

      const btn = document.createElement('button');
      btn.className = `level-pill-btn ${isCurrent ? 'active' : ''} ${isUnlocked ? 'unlocked' : 'locked'}`;

      let badge = `<span class="lvl-num">${i}</span>`;
      if (isCompleted) {
        badge = `<span class="lvl-num completed">✓</span>`;
      } else if (!isUnlocked) {
        badge = `<span class="lvl-num locked-icon">🔒</span>`;
      }

      btn.innerHTML = `${badge} <span class="lvl-name">${levelNames[i - 1]}</span>`;
      btn.onclick = () => {
        if (!isUnlocked) {
          if (confirm(`Stage ${i} is locked! Your highest unlocked is Stage ${highestUnlocked}. Jump ahead anyway?`)) {
            this.jumpToLevel(i);
          }
        } else {
          this.jumpToLevel(i);
        }
      };
      grid.appendChild(btn);
    }
  }

  // --- HINT TOGGLE SYSTEM (HIDDEN BY DEFAULT) ---

  toggleHint() {
    this.isHintVisible = !this.isHintVisible;
    window.soundFx.playPop();

    const body = document.getElementById('pepelo-hint-body');
    const eyeIcon = document.getElementById('pepelo-eye-icon');
    const eyeText = document.getElementById('pepelo-eye-text');

    if (body) {
      if (this.isHintVisible) {
        body.classList.remove('hidden');
      } else {
        body.classList.add('hidden');
      }
    }

    if (eyeIcon && eyeText) {
      if (this.isHintVisible) {
        eyeIcon.textContent = '🙈';
        eyeText.textContent = 'Hide Hint';
      } else {
        eyeIcon.textContent = '👁️';
        eyeText.textContent = 'Show Hint';
      }
    }
  }

  updateInstructionBanner(level) {
    const stageTitleEl = document.getElementById('pepelo-stage-title');
    const hintTextEl = document.getElementById('pepelo-hint-text');
    const body = document.getElementById('pepelo-hint-body');
    const eyeIcon = document.getElementById('pepelo-eye-icon');
    const eyeText = document.getElementById('pepelo-eye-text');

    // Keep hint hidden by default on each stage load
    this.isHintVisible = false;
    if (body) body.classList.add('hidden');
    if (eyeIcon) eyeIcon.textContent = '👁️';
    if (eyeText) eyeText.textContent = 'Show Hint';

    const hints = [
      // 1
      `Stage 1: Twin Bridges`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Step on the <b>Pink Button</b> to lower Bridge 1.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Cross over and press <b>GRAB (E)</b> to lift the <b>Golden Energy Cube</b>.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>🤴 King:</b> Place cube on the <b>Green Button</b> to open the gate.</span></div>
       <div class="hint-step"><span class="hint-num">4</span> <span><b>👫 Both:</b> Enter the <b>Golden Exit Portal</b>!</span></div>`,

      // 2
      `Stage 2: The Elevator`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Step onto the wooden <b>Elevator Platform</b>.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Stand on the <b>Blue Button</b> downstairs to raise the lift!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👸 Queen:</b> Step on the <b>Pink Button</b> upstairs to drop the ramp for King.</span></div>
       <div class="hint-step"><span class="hint-num">4</span> <span><b>👫 Both:</b> Meet at the high <b>Sanctuary Portal</b> together!</span></div>`,

      // 3
      `Stage 3: Stepping Stones`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Hold the <b>Center Button</b> to freeze the stepping stones in place!</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Hop across the stones and grab the Pink Energy Cube.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Both:</b> Place cube on the far plate and step into the portal!</span></div>`,

      // 4
      `Stage 4: Double Gate`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Step on Button 1 on your side to open King's door.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Walk through and step on Button 2 to open Queen's door.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Both:</b> Leapfrog forward and unite at the Exit Portal!</span></div>`,

      // 5
      `Stage 5: Crystal Lift`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Step on the cyan button to raise King on Lift B.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Reach the cliff and step on the gold button to raise Queen on Lift A!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Both:</b> Celebrate at the high crystal sanctuary!</span></div>`,

      // 6
      `Stage 6: Heavy Lifting`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen & 🤴 King:</b> Both grab one energy cube each.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👫 Both:</b> Place both cubes simultaneously on the twin scale buttons!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>🌉 Bridge:</b> The heavy drawbridge will drop across the chasm!</span></div>`,

      // 7
      `Stage 7: Color Resonance`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Walk the Pink Path and activate the Pink Resonator.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Walk the Blue Path and activate the Blue Resonator.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Both:</b> When both paths glow, the central gates dissolve!</span></div>`,

      // 8
      `Stage 8: Laser Grid`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Stand on the Green Shield Button to disable the red laser beam!</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Sprint through while the laser is safely turned off!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>🤴 King:</b> Hit the back switch so Queen can join you!</span></div>`,

      // 9
      `Stage 9: Rotating Gears`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👫 Timing:</b> Watch the rotating gears in the sky.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👸 Queen:</b> Step on the brake button to lock the first gear in place.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>🤴 King:</b> Cross over to the second gear and unlock the exit!</span></div>`,

      // 10
      `Stage 10: Seesaw Bridge`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>⚖️ Balance:</b> Queen stand on the left end, King stand on the right end.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👫 Harmony:</b> Equalize your weights to make the seesaw a horizontal bridge!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Both:</b> Walk into the portal together!</span></div>`,

      // 11
      `Stage 11: Sync Sprint`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>⏱️ Speed:</b> Both players stand ready near your distant buttons.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👫 Countdown:</b> 3-2-1 GO! Step on both buttons within 5 seconds!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>✨ Reward:</b> The golden skyway bridge will rise!</span></div>`,

      // 12
      `Stage 12: Conveyor Maze`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Toggle the conveyor direction plate to help King ride forward.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Reach the opposite shore and open the safe bypass for Queen!</span></div>`,

      // 13
      `Stage 13: Starry Crossway`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Step on the Pink Button to raise Bridge A for King.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Step on the Blue Button to raise Bridge B for Queen.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Meet:</b> Meet in the center starry sanctuary!</span></div>`,

      // 14
      `Stage 14: Sky Bouncers`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>🦘 High Jump:</b> Ride the elevated launch lift together.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👸 Queen:</b> Hold the upper switch to lock the lift on high cliff!</span></div>`,

      // 15
      `Stage 15: Cube Domino`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👸 Queen:</b> Carry the Pink Cube to Socket 1.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Carry the Blue Cube to Socket 2.</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>🌉 Bridge:</b> Both sockets active triggers the golden Domino bridge!</span></div>`,

      // 16
      `Stage 16: Mirror Chamber`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>🪞 Mirroring:</b> Move in mirror harmony across the twin glass islands.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👫 Sync:</b> Step on the twin green mirror plates at the same time!</span></div>`,

      // 17
      `Stage 17: Cloud Spire`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>🗼 Ascent:</b> King rides Lift 1 to mid-tower; Queen steps on blue plate.</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>👸 Queen:</b> King sends down Lift 2 from mid-tower. Both ascend to the spire summit!</span></div>`,

      // 18
      `Stage 18: Laser Gauntlet`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>⚡ Coordination:</b> Alternate stepping on buttons 1 and 2 to pass through the dual barrier.</span></div>`,

      // 19
      `Stage 19: Trial of Trust`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>🤝 Faith:</b> The glass bridge looks invisible, but it solidifies while Queen stands on the Trust Altar!</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>🤴 King:</b> Cross the bridge safely and unlock the door from the other side!</span></div>`,

      // 20
      `Stage 20: Eternal Sanctuary (GRAND FINALE)`,
      `<div class="hint-step"><span class="hint-num">1</span> <span><b>👑 Grand Finale:</b> Both players grab their Royal Cubes!</span></div>
       <div class="hint-step"><span class="hint-num">2</span> <span><b>💖 Heart Altar:</b> Place both cubes on the dual golden altars!</span></div>
       <div class="hint-step"><span class="hint-num">3</span> <span><b>👫 Eternity:</b> Run hand-in-hand into the Giant Crowned Heart Vortex to claim victory over all 20 stages!</span></div>`
    ];

    const idx = (level - 1) * 2;
    if (stageTitleEl) stageTitleEl.textContent = hints[idx] || `Stage ${level}`;
    if (hintTextEl) hintTextEl.innerHTML = hints[idx + 1] || `Work together to reach the portal!`;
  }

  onWindowResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  stop() {
    this.isActive = false;
    if (this.renderer) {
      this.renderer.dispose();
    }
  }
}

window.pepeloGame = new PepeloCoopGame();
